
import React, { useState, useEffect, useRef } from 'react';
import { Volume2, X, MousePointer2, BookOpen, ChevronRight, Loader2, Volume1, VolumeX, Gauge, Zap } from 'lucide-react';
import { playBuffer, synthesizeText, speakText, splitIntoChunks } from '../services/ttsService';
import { Chat, ViewType } from '../types';

const VOICES = [
  { id: 'Zephyr', label: 'Brittany' },
  { id: 'Puck', label: 'Ryo' },
  { id: 'Charon', label: 'Gary' },
  { id: 'Kore', label: 'Kore' },
  { id: 'Fenrir', label: 'Mordechai' }
];

interface FloatingTTSProps {
  activeChat: Chat | null;
  view: ViewType;
}

const FloatingTTS: React.FC<FloatingTTSProps> = ({ activeChat, view }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState(VOICES[1].id);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [isSnipping, setIsSnipping] = useState(false);
  const [isReading, setIsReading] = useState(false);
  const [snipCoords, setSnipCoords] = useState<{ x1: number, y1: number, x2: number, y2: number } | null>(null);
  
  const currentSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const stopReadingRef = useRef(false);

  const stopCurrentAudio = () => {
    stopReadingRef.current = true;
    if (currentSourceRef.current) {
      try {
        currentSourceRef.current.stop();
      } catch (e) {}
      currentSourceRef.current = null;
    }
    setIsReading(false);
  };

  const handleReadPage = async () => {
    if (!activeChat || activeChat.messages.length === 0) return;
    
    stopCurrentAudio();
    stopReadingRef.current = false;
    setIsReading(true);

    const chunks: { text: string, voice: string }[] = [];
    activeChat.messages.forEach(m => {
      const voice = m.role === 'user' ? 'Charon' : selectedVoice;
      const textChunks = splitIntoChunks(m.text);
      textChunks.forEach(tc => chunks.push({ text: tc, voice }));
    });

    const buffers: (AudioBuffer | null)[] = new Array(chunks.length).fill(null);
    const tasks: (Promise<void> | null)[] = new Array(chunks.length).fill(null);

    const getBuffer = async (index: number) => {
      if (index >= chunks.length || index < 0) return null;
      if (buffers[index]) return buffers[index];
      if (!tasks[index]) {
        tasks[index] = (async () => {
          try {
            buffers[index] = await synthesizeText(chunks[index].text, chunks[index].voice);
          } catch (e) {
            console.error(`Buffering chunk ${index} failed`, e);
          }
        })();
      }
      await tasks[index];
      return buffers[index];
    };

    try {
      for (let i = 0; i < Math.min(chunks.length, 5); i++) {
        getBuffer(i);
      }

      for (let i = 0; i < chunks.length; i++) {
        if (stopReadingRef.current) break;
        if (i + 5 < chunks.length) getBuffer(i + 5);

        const buffer = await getBuffer(i);
        
        if (buffer && !stopReadingRef.current) {
          const source = playBuffer(buffer, playbackSpeed);
          currentSourceRef.current = source;
          
          await new Promise((resolve) => {
            source.onended = resolve;
            const checkStop = setInterval(() => {
              if (stopReadingRef.current) {
                clearInterval(checkStop);
                resolve(null);
              }
            }, 20);
          });
        }
      }
    } catch (error) {
      console.error("Turbo reading encountered an error:", error);
    } finally {
      setIsReading(false);
    }
  };

  const startSnipping = () => {
    setIsSnipping(true);
    setIsOpen(false);
  };

  const cancelSnipping = () => {
    setIsSnipping(false);
    setSnipCoords(null);
  };

  useEffect(() => {
    if (!isSnipping) return;

    const handleMouseDown = (e: MouseEvent) => {
      setSnipCoords({ x1: e.clientX, y1: e.clientY, x2: e.clientX, y2: e.clientY });
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (snipCoords) {
        setSnipCoords(prev => prev ? { ...prev, x2: e.clientX, y2: e.clientY } : null);
      }
    };

    const handleMouseUp = async () => {
      if (snipCoords) {
        const { x1, y1, x2, y2 } = snipCoords;
        const left = Math.min(x1, x2);
        const top = Math.min(y1, y2);
        const right = Math.max(x1, x2);
        const bottom = Math.max(y1, y2);

        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
        let capturedText = "";
        let node;
        while (node = walker.nextNode()) {
          const parent = node.parentElement;
          if (parent) {
            const rect = parent.getBoundingClientRect();
            if (rect.left >= left && rect.right <= right && rect.top >= top && rect.bottom <= bottom) {
              capturedText += node.textContent + " ";
            }
          }
        }

        if (capturedText.trim()) {
          stopCurrentAudio();
          stopReadingRef.current = false;
          setIsReading(true);
          await speakText(capturedText.trim(), selectedVoice, playbackSpeed);
          setIsReading(false);
        }

        cancelSnipping();
      }
    };

    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isSnipping, snipCoords, selectedVoice, playbackSpeed]);

  // Determine container position classes based on active view
  const isInputView = view === 'research' || view === 'site-finder' || view === 'brief';
  
  // bottom-5 right-5 is ~20px from corner (Tailwind 5 = 1.25rem = 20px)
  // bottom-[130px] md:bottom-[140px] is approximately 20px above the fixed input bar on those pages
  const positionClasses = isInputView 
    ? "bottom-[120px] right-6 md:bottom-[130px] md:right-8" 
    : "bottom-5 right-5 md:bottom-5 md:right-5";

  return (
    <>
      {/* Snip Overlay */}
      {isSnipping && (
        <div className="fixed inset-0 z-[300] cursor-crosshair bg-slate-900/10 backdrop-blur-[1px]">
          <div className="absolute top-6 left-1/2 -translate-x-1/2 bg-white dark:bg-slate-900 px-6 py-3 rounded-2xl shadow-2xl border border-indigo-200 dark:border-indigo-800 flex items-center gap-3">
            <MousePointer2 className="text-indigo-600 animate-bounce" size={18} />
            <span className="text-sm font-bold text-slate-700 dark:text-slate-100 uppercase tracking-widest">Select text area to read</span>
            <button onClick={cancelSnipping} className="ml-4 p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400">
              <X size={16} />
            </button>
          </div>
          {snipCoords && (
            <div 
              className="absolute border-2 border-indigo-600 bg-indigo-500/10 rounded"
              style={{
                left: Math.min(snipCoords.x1, snipCoords.x2),
                top: Math.min(snipCoords.y1, snipCoords.y2),
                width: Math.abs(snipCoords.x1 - snipCoords.x2),
                height: Math.abs(snipCoords.y1 - snipCoords.y2)
              }}
            />
          )}
        </div>
      )}

      {/* Floating Controls */}
      <div className={`fixed z-[250] flex flex-col items-end gap-3 pointer-events-none transition-all duration-500 ease-in-out ${positionClasses}`}>
        {isOpen && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2rem] shadow-2xl p-6 w-72 animate-in slide-in-from-bottom-4 duration-300 pointer-events-auto">
            <div className="flex items-center justify-between mb-4 px-1">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-600">Audio Synthesizer</h3>
              <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={16}/></button>
            </div>

            <div className="space-y-2 mb-6">
              {VOICES.map(v => (
                <button
                  key={v.id}
                  onClick={() => setSelectedVoice(v.id)}
                  className={`w-full flex items-center justify-between px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                    selectedVoice === v.id 
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-100 dark:shadow-indigo-900/40' 
                    : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {v.label}
                  {selectedVoice === v.id && <Volume1 size={14} />}
                </button>
              ))}
            </div>

            {/* Speed Control */}
            <div className="mb-6 px-1">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500">
                  <Gauge size={14} />
                  Playback Speed
                </div>
                <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">{playbackSpeed.toFixed(2)}x</span>
              </div>
              <input 
                type="range" 
                min="0.25" 
                max="5.0" 
                step="0.25" 
                value={playbackSpeed} 
                onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[8px] font-bold text-slate-300 dark:text-slate-600 mt-1 uppercase">
                <span>Slow</span>
                <span>Normal</span>
                <span>Fast</span>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-2 border-t border-slate-100 dark:border-slate-800 pt-4">
              <button 
                onClick={handleReadPage}
                disabled={!activeChat || activeChat.messages.length === 0 || isReading}
                className="w-full flex items-center gap-3 px-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-700 transition-all disabled:opacity-50"
              >
                <div className="relative">
                  <BookOpen size={16} className="text-indigo-600" />
                  <Zap size={8} className="absolute -top-1 -right-1 text-orange-500 fill-orange-500" />
                </div>
                Instant Turbo Read
              </button>
              <button 
                onClick={startSnipping}
                className="w-full flex items-center gap-3 px-4 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
              >
                <MousePointer2 size={16} className="text-indigo-600" />
                Select & Read
              </button>
            </div>
          </div>
        )}

        <div className="flex items-center gap-3">
          {isReading && (
            <button 
              onClick={stopCurrentAudio}
              className="bg-red-500 text-white p-4 rounded-2xl shadow-xl animate-in fade-in zoom-in duration-300 pointer-events-auto"
              title="Stop Audio"
            >
              <VolumeX size={24} />
            </button>
          )}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={`w-16 h-16 rounded-[2rem] flex items-center justify-center transition-all shadow-2xl pointer-events-auto ${
              isOpen || isReading ? 'bg-indigo-600 text-white scale-110 rotate-12' : 'bg-white dark:bg-slate-900 text-indigo-600 border border-slate-100 dark:border-slate-800 hover:scale-110'
            }`}
          >
            {isReading ? <Loader2 className="animate-spin" size={24} /> : <Volume2 size={24} />}
          </button>
        </div>
      </div>
    </>
  );
};

export default FloatingTTS;
