
import { Plus, FolderOpen, GraduationCap, Github, BrainCircuit, Search, ChevronDown, ChevronRight, MessageSquare, Settings as SettingsIcon, Edit3, Check, UserCircle, Globe, Zap, Trash2, Share2, PanelLeftClose, PanelLeftOpen, SearchIcon, X, Search as SearchIconComponent, Mic, Clock, Info } from 'lucide-react';
import React, { useState, useMemo, useEffect } from 'react';
import { Project, Chat, ViewType, AIPersonality } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  projects: Project[];
  chats: Chat[];
  savedSharedChats: {name: string, data: string}[];
  activeProjectId: string | null;
  activeChatId: string | null;
  onNewProject: () => void;
  onNewChat: (projectId: string) => void;
  onSelectProject: (id: string) => void;
  onSelectChat: (id: string) => void;
  onSelectShared: (data: string) => void;
  onDeleteSavedShared: (data: string) => void;
  onRenameProject: (id: string, newName: string) => void;
  onDeleteProject: (id: string) => void;
  onRenameChat: (id: string, newName: string) => void;
  onDeleteChat: (id: string) => void;
  onChangeProjectPersonality: (id: string, personality: AIPersonality) => void;
  view: ViewType;
  onSetView: (view: ViewType) => void;
  onOpenSettings: () => void;
  onOpenAbout: () => void;
  isSearchModalOpen: boolean;
  setIsSearchModalOpen: (open: boolean) => void;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  projects, 
  chats,
  savedSharedChats,
  activeProjectId, 
  activeChatId,
  onNewProject, 
  onNewChat,
  onSelectProject, 
  onSelectChat,
  onSelectShared,
  onDeleteSavedShared,
  onRenameProject,
  onDeleteProject,
  onRenameChat,
  onDeleteChat,
  onChangeProjectPersonality,
  view,
  onSetView,
  onOpenSettings,
  onOpenAbout,
  isSearchModalOpen,
  setIsSearchModalOpen
}) => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedProjects, setExpandedProjects] = useState<Set<string>>(new Set());
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [editingChatId, setEditingChatId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  // Search logic: Filter chats that contain the search query in any of their messages
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    
    return chats.map(chat => {
      const matchedMessages = chat.messages.filter(msg => 
        msg.text.toLowerCase().includes(query)
      );
      
      if (matchedMessages.length > 0) {
        return {
          ...chat,
          matchSnippet: matchedMessages[0].text,
          matchCount: matchedMessages.length
        };
      }
      return null;
    }).filter(Boolean);
  }, [chats, searchQuery]);

  const toggleProject = (id: string) => {
    const next = new Set(expandedProjects);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setExpandedProjects(next);
  };

  const startEditingProject = (p: Project) => {
    setEditingProjectId(p.id);
    setEditName(p.name);
  };

  const saveEditProject = (id: string) => {
    if (editName.trim()) onRenameProject(id, editName);
    setEditingProjectId(null);
  };

  const startEditingChat = (c: Chat) => {
    setEditingChatId(c.id);
    setEditName(c.name);
  };

  const saveEditChat = (id: string) => {
    if (editName.trim()) onRenameChat(id, editName);
    setEditingChatId(null);
  };

  const currentHash = window.location.hash;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setIsSearchModalOpen]);

  return (
    <div className="flex h-screen w-full bg-slate-50 dark:bg-slate-950 overflow-hidden">
      {/* Search Modal */}
      {isSearchModalOpen && (
        <div className="fixed inset-0 z-[200] flex items-start justify-center pt-[10vh] px-4">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-md" onClick={() => setIsSearchModalOpen(false)} />
          <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden relative flex flex-col max-h-[70vh] animate-in fade-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center gap-4">
              <SearchIconComponent className="text-indigo-600 shrink-0" size={24} />
              <input 
                autoFocus
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search deep chat content..."
                className="flex-1 bg-transparent border-none outline-none text-lg font-medium text-slate-800 dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600"
              />
              <button 
                onClick={() => setIsSearchModalOpen(false)}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl text-slate-400 transition-all"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {searchQuery.trim() === '' ? (
                <div className="h-40 flex flex-col items-center justify-center text-slate-400 space-y-2">
                  <SearchIconComponent size={32} className="opacity-20" />
                  <p className="text-sm font-medium">Type to search across all research sessions</p>
                </div>
              ) : searchResults.length > 0 ? (
                searchResults.map((result: any) => {
                  const project = projects.find(p => p.id === result.projectId);
                  return (
                    <button
                      key={result.id}
                      onClick={() => {
                        onSelectChat(result.id);
                        setIsSearchModalOpen(false);
                        setSearchQuery('');
                      }}
                      className="w-full text-left p-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-3xl border border-transparent hover:border-slate-100 dark:hover:border-slate-800 transition-all group"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-black uppercase tracking-widest text-indigo-500">
                          {project?.name || 'Project'}
                        </span>
                        <span className="text-[10px] bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full font-bold">
                          {result.matchCount} {result.matchCount === 1 ? 'match' : 'matches'}
                        </span>
                      </div>
                      <h4 className="text-base font-bold text-slate-800 dark:text-slate-100 mb-2 group-hover:text-indigo-600 transition-colors">
                        {result.name}
                        {result.isTemporary && <Clock size={12} className="inline ml-2 text-indigo-400" />}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 italic bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800 group-hover:bg-white dark:group-hover:bg-slate-800 transition-colors">
                        "...{result.matchSnippet}..."
                      </p>
                    </button>
                  );
                })
              ) : (
                <div className="h-40 flex flex-col items-center justify-center text-slate-400 space-y-2">
                  <X size={32} className="opacity-20" />
                  <p className="text-sm font-medium">No results found for "{searchQuery}"</p>
                </div>
              )}
            </div>
            
            <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-slate-400">
              <div className="flex gap-4">
                <span><kbd className="bg-white dark:bg-slate-800 border dark:border-slate-700 rounded px-1.5 py-0.5 mr-1">↑↓</kbd> Navigate</span>
                <span><kbd className="bg-white dark:bg-slate-800 border dark:border-slate-700 rounded px-1.5 py-0.5 mr-1">Enter</kbd> Select</span>
              </div>
              <span>Searching {chats.length} Sessions</span>
            </div>
          </div>
        </div>
      )}

      <aside 
        className={`${isSidebarCollapsed ? 'w-16' : 'w-72'} bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col hidden md:flex shrink-0 transition-all duration-300 ease-in-out relative group`}
      >
        <button 
          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          className="absolute -right-3 top-20 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full p-1.5 text-slate-400 hover:text-indigo-600 shadow-sm z-50 transition-all hover:scale-110"
          title={isSidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
        >
          {isSidebarCollapsed ? <PanelLeftOpen size={14} /> : <PanelLeftClose size={14} />}
        </button>

        <div className={`p-6 flex items-center gap-3 text-indigo-600 font-bold text-xl border-b border-slate-100 dark:border-slate-800 overflow-hidden whitespace-nowrap transition-all ${isSidebarCollapsed ? 'px-4 justify-center' : ''}`}>
          <GraduationCap size={32} className="shrink-0" />
          {!isSidebarCollapsed && <span>Ryo AI</span>}
        </div>

        <div className={`px-4 pt-4 pb-2 ${isSidebarCollapsed ? 'flex justify-center' : ''}`}>
          <button 
            onClick={() => setIsSearchModalOpen(true)}
            className={`flex items-center gap-3 w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-xl text-slate-400 hover:text-indigo-600 hover:border-indigo-100 dark:hover:border-indigo-900 transition-all ${isSidebarCollapsed ? 'justify-center w-10 h-10 p-0' : 'text-xs'}`}
            title="Search Chats (Ctrl+K)"
          >
            <SearchIcon size={isSidebarCollapsed ? 18 : 14} className="shrink-0" />
            {!isSidebarCollapsed && (
              <div className="flex items-center justify-between flex-1">
                <span>Search everything...</span>
                <span className="text-[9px] bg-slate-200/50 dark:bg-slate-700/50 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700">⌘K</span>
              </div>
            )}
          </button>
        </div>

        <div className={`p-4 space-y-1 ${isSidebarCollapsed ? 'px-2' : ''}`}>
          {[
            { id: 'research', label: 'Research Lab', icon: <SearchIconComponent size={18} />, hash: '#/research', color: 'indigo' },
            { id: 'voice', label: 'Voice Research', icon: <Mic size={18} />, hash: '#/voice', color: 'indigo' },
            { id: 'brief', label: 'Brief Answers', icon: <Zap size={18} />, hash: '#/brief', color: 'orange' },
            { id: 'site-finder', label: 'Site Finder', icon: <Globe size={18} />, hash: '#/site-finder', color: 'indigo' },
            { id: 'flashcards', label: 'Study Cards', icon: <BrainCircuit size={18} />, hash: '#/flashcards', color: 'indigo' },
          ].map(item => (
            <button 
              key={item.id}
              onClick={() => window.location.hash = item.hash} 
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all font-medium whitespace-nowrap overflow-hidden ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${
                view === item.id && !currentHash.includes('shared') 
                ? (item.color === 'orange' ? 'bg-orange-500 text-white shadow-lg' : 'bg-indigo-600 text-white shadow-lg') 
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
              }`}
              title={isSidebarCollapsed ? item.label : ''}
            >
              <span className="shrink-0">{item.icon}</span>
              {!isSidebarCollapsed && <span>{item.label}</span>}
            </button>
          ))}
        </div>

        <div className="flex-1 flex flex-col min-h-0 border-t border-slate-50 dark:border-slate-800">
          <div className={`px-4 py-3 flex items-center text-xs font-bold text-slate-400 dark:text-slate-600 uppercase tracking-widest transition-all ${isSidebarCollapsed ? 'justify-center px-0 opacity-50' : 'justify-between'}`}>
            {!isSidebarCollapsed && <span>Your Projects</span>}
            <button 
              onClick={onNewProject} 
              className="p-1.5 hover:text-white hover:bg-indigo-600 transition-all text-indigo-600 bg-indigo-50 dark:bg-indigo-950 rounded-md shrink-0 flex items-center justify-center"
              title="New Project"
            >
              <Plus size={16} />
            </button>
          </div>
          
          <nav className="flex-1 overflow-y-auto px-2 space-y-1 pb-6">
            {projects.map(project => {
              const projectChats = chats.filter(c => c.projectId === project.id);
              const isExpanded = expandedProjects.has(project.id);
              const isEditing = editingProjectId === project.id;
              const isProjectActive = activeProjectId === project.id;
              
              return (
                <div key={project.id} className="space-y-1">
                  <div 
                    className={`group flex items-center gap-2 px-2 py-2 rounded-lg text-sm transition-all cursor-pointer overflow-hidden ${isSidebarCollapsed ? 'justify-center' : ''} ${isProjectActive ? 'bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-slate-100 font-semibold' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/30'}`} 
                    onClick={() => { toggleProject(project.id); onSelectProject(project.id); }}
                    title={isSidebarCollapsed ? project.name : ''}
                  >
                    {!isSidebarCollapsed && (
                      <button 
                        className="text-slate-300 dark:text-slate-600 shrink-0 p-1 hover:bg-slate-200/50 dark:hover:bg-slate-700/50 rounded-md transition-colors"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleProject(project.id);
                        }}
                      >
                        {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                      </button>
                    )}
                    <FolderOpen size={16} className={isProjectActive ? 'text-indigo-500 shrink-0' : 'text-slate-400 dark:text-slate-600 shrink-0'} />
                    {!isSidebarCollapsed && (
                      <>
                        {isEditing ? (
                          <div className="flex items-center gap-1 flex-1 min-w-0" onClick={e => e.stopPropagation()}>
                            <input autoFocus className="w-full bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-900 rounded px-1.5 py-0.5 text-xs focus:outline-none dark:text-slate-100" value={editName} onChange={e => setEditName(e.target.value)} onKeyDown={e => e.key === 'Enter' && saveEditProject(project.id)} />
                            <button onClick={() => saveEditProject(project.id)} className="text-emerald-500"><Check size={14}/></button>
                          </div>
                        ) : <span className="truncate flex-1">{project.name}</span>}
                        {!isEditing && (
                          <div className="flex items-center opacity-0 group-hover:opacity-100 gap-1 shrink-0" onClick={e => e.stopPropagation()}>
                            <button onClick={() => startEditingProject(project)} className="p-1 text-slate-400 dark:text-slate-600 hover:text-indigo-500"><Edit3 size={13}/></button>
                            <button onClick={() => { if(confirm(`Delete project "${project.name}"?`)) onDeleteProject(project.id); }} className="p-1 text-slate-400 dark:text-slate-600 hover:text-red-500"><Trash2 size={13}/></button>
                            <button onClick={() => onNewChat(project.id)} className="p-1 text-indigo-400 hover:text-indigo-600"><Plus size={14}/></button>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                  {isExpanded && !isSidebarCollapsed && (
                    <div className="ml-5 space-y-1 border-l border-slate-100 dark:border-slate-800 pl-3 pt-1 pb-1">
                      {projectChats.map(chat => {
                        const isEditingChat = editingChatId === chat.id;
                        return (
                          <div key={chat.id} className="group flex items-center animate-in slide-in-from-left-2 duration-200">
                            <button onClick={() => onSelectChat(chat.id)} className={`flex-1 flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-colors text-left truncate ${activeChatId === chat.id ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-400 font-bold' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/30'}`}>
                              {chat.isTemporary ? <Clock size={14} className={activeChatId === chat.id ? 'text-indigo-500' : 'text-slate-300 dark:text-slate-700'} /> : <MessageSquare size={14} className={activeChatId === chat.id ? 'text-indigo-500' : 'text-slate-300 dark:text-slate-700'} />}
                              {isEditingChat ? (
                                <div className="flex items-center gap-1 flex-1 min-w-0" onClick={e => e.stopPropagation()}>
                                  <input autoFocus className="w-full bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-900 rounded px-1.5 py-0.5 text-xs focus:outline-none dark:text-slate-100" value={editName} onChange={e => setEditName(e.target.value)} onKeyDown={e => e.key === 'Enter' && saveEditChat(chat.id)} />
                                  <button onClick={() => saveEditChat(chat.id)} className="text-emerald-500 shrink-0"><Check size={12}/></button>
                                </div>
                              ) : <span className="truncate">{chat.name}</span>}
                            </button>
                            {!isEditingChat && <div className="flex items-center opacity-0 group-hover:opacity-100 gap-1 ml-1 px-1"><button onClick={() => startEditingChat(chat)} className="p-1 text-slate-300 dark:text-slate-600 hover:text-indigo-500"><Edit3 size={12}/></button><button onClick={() => onDeleteChat(chat.id)} className="p-1 text-slate-300 dark:text-slate-600 hover:text-red-500"><Trash2 size={12}/></button></div>}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}

            {savedSharedChats.length > 0 && (
              <div className={`mt-8 space-y-1 transition-all ${isSidebarCollapsed ? 'opacity-50' : ''}`}>
                <div className={`px-2 py-3 text-xs font-bold text-slate-400 dark:text-slate-600 uppercase tracking-widest border-t border-slate-50 dark:border-slate-800 ${isSidebarCollapsed ? 'text-center px-0' : ''}`}>
                  {!isSidebarCollapsed ? 'Shared Research' : <Share2 size={12} className="inline" />}
                </div>
                {savedSharedChats.map((shared) => (
                  <div key={shared.data} className={`group flex items-center ${isSidebarCollapsed ? 'justify-center' : ''}`}>
                    <button 
                      onClick={() => onSelectShared(shared.data)} 
                      className={`flex-1 flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-colors text-left truncate ${isSidebarCollapsed ? 'justify-center px-0' : ''} ${currentHash === `#/shared/${shared.data}` ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-400 font-bold' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/30'}`}
                      title={isSidebarCollapsed ? shared.name : ''}
                    >
                      <Share2 size={14} className={currentHash === `#/shared/${shared.data}` ? 'text-indigo-500' : 'text-slate-300 dark:text-slate-700'} />
                      {!isSidebarCollapsed && <span className="truncate">{shared.name}</span>}
                    </button>
                    {!isSidebarCollapsed && (
                      <div className="flex items-center opacity-0 group-hover:opacity-100 gap-1 ml-1 px-1">
                        <button onClick={() => onDeleteSavedShared(shared.data)} className="p-1 text-slate-300 dark:text-slate-600 hover:text-red-500 transition-all">
                          <Trash2 size={12} />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </nav>
        </div>

        <div className={`p-4 border-t border-slate-100 dark:border-slate-800 mt-auto bg-slate-50/50 dark:bg-slate-950 transition-all flex items-center gap-2 ${isSidebarCollapsed ? 'px-2 flex-col' : ''}`}>
            <button 
              onClick={onOpenSettings} 
              className={`flex-1 flex items-center gap-3 px-3 py-2.5 bg-white dark:bg-slate-800 rounded-[10px] text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all text-sm font-medium shadow-sm ${isSidebarCollapsed ? 'justify-center px-0 w-full' : ''}`}
              title={isSidebarCollapsed ? "Integrity Vault" : ""}
            >
              <SettingsIcon size={18} className="shrink-0" /> 
              {!isSidebarCollapsed && <span className="truncate">Vault</span>}
            </button>
            <button 
              onClick={onOpenAbout} 
              className={`flex-1 flex items-center gap-3 px-3 py-2.5 bg-white dark:bg-slate-800 rounded-[10px] text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all text-sm font-medium shadow-sm ${isSidebarCollapsed ? 'justify-center px-0 w-full' : ''}`}
              title={isSidebarCollapsed ? "About Ryo AI" : ""}
            >
              <Info size={18} className="shrink-0" />
              {!isSidebarCollapsed && <span>About</span>}
            </button>
        </div>
      </aside>
      <main className="flex-1 flex flex-col relative min-w-0 overflow-y-auto">{children}</main>
    </div>
  );
};

export default Layout;
