
import React, { useState } from 'react';
import { copyToClipboard } from '../services/copying';

interface InteractiveTextProps {
  text: string;
  className?: string;
}

const InteractiveText: React.FC<InteractiveTextProps> = ({ text, className = "" }) => {
  const [copiedWord, setCopiedWord] = useState<{ word: string; x: number; y: number } | null>(null);

  const handleWordClick = async (e: React.MouseEvent, word: string) => {
    e.stopPropagation();
    // Clean word of punctuation and markdown artifacts for better copying
    const cleanWord = word.replace(/[.,!?;:()]/g, "").replace(/[*#_~`]/g, "");
    if (!cleanWord) return;

    const success = await copyToClipboard(cleanWord);
    if (success) {
      setCopiedWord({ word: cleanWord, x: e.clientX, y: e.clientY });
      setTimeout(() => setCopiedWord(null), 1000);
    }
  };

  // Helper to strip annoying formatting characters from display text
  const sanitizeDisplay = (t: string) => {
    return t.replace(/[*#_~`]|---/g, '');
  };

  // Split text by words but keep spaces and newlines
  const parts = text.split(/(\s+)/);

  return (
    <div className={`relative whitespace-pre-wrap ${className}`}>
      {parts.map((part, i) => {
        if (/\s+/.test(part)) {
          return <span key={i}>{part}</span>;
        }

        const displayPart = sanitizeDisplay(part);
        if (!displayPart && part.length > 0) return null; // Skip if part was just symbols

        return (
          <span
            key={i}
            onClick={(e) => handleWordClick(e, part)}
            className="cursor-pointer hover:bg-indigo-100/50 rounded transition-colors duration-100 active:scale-95 inline-block"
            title="Click to copy word"
          >
            {displayPart}
          </span>
        );
      })}

      {/* Floating Feedback Tag */}
      {copiedWord && (
        <div 
          className="fixed z-[1000] pointer-events-none animate-in fade-in slide-in-from-bottom-2 duration-300 bg-slate-800 text-white text-[10px] font-bold px-2 py-1 rounded shadow-lg uppercase tracking-tighter"
          style={{ top: copiedWord.y - 30, left: copiedWord.x - 20 }}
        >
          Copied!
        </div>
      )}
    </div>
  );
};

export default InteractiveText;
