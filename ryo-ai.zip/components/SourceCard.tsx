
import React, { useState } from 'react';
import { ExternalLink, ShieldCheck, Copy, Check, BookOpen } from 'lucide-react';
import { GroundingSource } from '../types';
import { copyToClipboard } from '../services/copying';

interface SourceCardProps {
  sources: GroundingSource[];
}

const SourceCard: React.FC<SourceCardProps> = ({ sources }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!sources || sources.length === 0) {
    return null;
  }

  const handleCopy = async (uri: string, index: number) => {
    const success = await copyToClipboard(uri);
    if (success) {
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    }
  };

  return (
    <div className="w-full space-y-3 animate-in fade-in slide-in-from-top-2 duration-500">
      <div className="flex items-center gap-2 text-[10px] font-black text-slate-400 dark:text-slate-600 uppercase tracking-[0.2em] px-2 mb-1">
        <BookOpen size={12} className="text-indigo-400" />
        Verified Academic Archive ({sources.length})
      </div>
      <div className="grid gap-2">
        {sources.map((source, index) => (
          <div
            key={index}
            className="flex flex-col gap-1 px-4 py-3 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl text-xs shadow-sm hover:shadow-md transition-all text-slate-600 dark:text-slate-400 group break-all"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="font-bold text-slate-700 dark:text-slate-200 truncate">{source.title}</span>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => handleCopy(source.uri, index)}
                  className={`p-1.5 border rounded-lg transition-all ${
                    copiedIndex === index 
                      ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800' 
                      : 'bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 border-slate-100 dark:border-slate-800'
                  }`}
                  title="Copy Link"
                >
                  {copiedIndex === index ? <Check size={12} /> : <Copy size={12} />}
                </button>
                <a
                  href={source.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 bg-white dark:bg-slate-800 hover:bg-indigo-600 hover:text-white text-indigo-500 border border-slate-100 dark:border-slate-800 rounded-lg transition-all"
                  title="Visit Page"
                >
                  <ExternalLink size={12} />
                </a>
              </div>
            </div>
            <span className="text-[10px] text-slate-400 dark:text-slate-600 font-mono overflow-hidden text-ellipsis opacity-60 group-hover:opacity-100 transition-opacity">
              {source.uri}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SourceCard;
