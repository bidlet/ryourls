
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';
import { Mic, MicOff, Settings, Volume2, Loader2, ShieldCheck, UserCircle, MessageSquare, GraduationCap, Play, Volume1, Search, BookOpen, Brain, Zap, MicOff as MuteIcon, Save, Check } from 'lucide-react';
import { UserSettings, Project } from '../types';

interface VoiceSessionProps {
  settings: UserSettings;
  activeProject?: Project;
  onUpdateProjectVoice?: (projectId: string, voiceId: string) => void;
}

const VOICES = [
  { id: 'Zephyr', label: 'Brittany', isDefault: false },
  { id: 'Puck', label: 'Ryo', isDefault: true },
  { id: 'Charon', label: 'Gary', isDefault: false },
  { id: 'Kore', label: 'Kore', isDefault: false },
  { id: 'Fenrir', label: 'Mordechai', isDefault: false }
];

const RESEARCH_MESSAGES = ['Researching', 'Learning', 'Reading', 'Analyzing', 'Summarizing', 'Verifying'];

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

const VoiceSession: React.FC<VoiceSessionProps> = ({ settings, activeProject, onUpdateProjectVoice }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [selectedVoiceId, setSelectedVoiceId] = useState(() => {
    if (activeProject?.defaultVoiceId) return activeProject.defaultVoiceId;
    return VOICES.find(v => v.isDefault)?.id || VOICES[0].id;
  });
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);
  const [inputTranscription, setInputTranscription] = useState('');
  const [outputTranscription, setOutputTranscription] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [previewingVoice, setPreviewingVoice] = useState<string | null>(null);
  const [isResearching, setIsResearching] = useState(false);
  const [statusIndex, setStatusIndex] = useState(0);
  const [isVoiceSaved, setIsVoiceSaved] = useState(false);

  const audioContextsRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const sessionRef = useRef<any>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const nextStartTimeRef = useRef(0);
  const transcriptionRef = useRef({ input: '', output: '' });
  const statusTimerRef = useRef<number | null>(null);
  const isMutedRef = useRef(false);

  // Update selected voice if the project default changes
  useEffect(() => {
    if (activeProject?.defaultVoiceId) {
      setSelectedVoiceId(activeProject.defaultVoiceId);
      setIsVoiceSaved(true);
    } else {
      setIsVoiceSaved(false);
    }
  }, [activeProject?.defaultVoiceId, activeProject?.id]);

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  useEffect(() => {
    if (isResearching) {
      statusTimerRef.current = window.setInterval(() => {
        setStatusIndex(prev => (prev + 1) % RESEARCH_MESSAGES.length);
      }, 1500);
    } else {
      if (statusTimerRef.current) clearInterval(statusTimerRef.current);
      setStatusIndex(0);
    }
    return () => { if (statusTimerRef.current) clearInterval(statusTimerRef.current); };
  }, [isResearching]);

  const stopSession = () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (audioContextsRef.current) {
      try {
        audioContextsRef.current.input.close();
        audioContextsRef.current.output.close();
      } catch (e) {
        console.warn("Error closing audio context", e);
      }
      audioContextsRef.current = null;
    }
    setIsActive(false);
    setIsConnecting(false);
    setIsResearching(false);
    setIsMuted(false);
    setInputTranscription('');
    setOutputTranscription('');
    transcriptionRef.current = { input: '', output: '' };
    
    sourcesRef.current.forEach(source => {
      try { source.stop(); } catch(e) {}
    });
    sourcesRef.current.clear();
    nextStartTimeRef.current = 0;
  };

  const startSession = async () => {
    if (isConnecting) return;
    
    setIsConnecting(true);
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextsRef.current = { input: inputAudioContext, output: outputAudioContext };

      const outputNode = outputAudioContext.createGain();
      outputNode.connect(outputAudioContext.destination);

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            const source = inputAudioContext.createMediaStreamSource(stream);
            const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              if (isMutedRef.current) return;

              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob: Blob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              sessionPromise.then(session => {
                if (session) {
                  session.sendRealtimeInput({ media: pcmBlob });
                }
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);
            setIsActive(true);
            setIsConnecting(false);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.toolCall) {
              setIsResearching(true);
            }

            if (message.serverContent?.outputTranscription) {
              transcriptionRef.current.output += message.serverContent.outputTranscription.text;
              setOutputTranscription(transcriptionRef.current.output);
            } else if (message.serverContent?.inputTranscription) {
              transcriptionRef.current.input += message.serverContent.inputTranscription.text;
              setInputTranscription(transcriptionRef.current.input);
            }

            if (message.serverContent?.turnComplete) {
              transcriptionRef.current.input = '';
              transcriptionRef.current.output = '';
              setIsResearching(false);
            }

            const modelTurnParts = message.serverContent?.modelTurn?.parts;
            if (modelTurnParts) {
              for (const part of modelTurnParts) {
                if (part.inlineData?.data) {
                  const base64Audio = part.inlineData.data;
                  nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
                  const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContext, 24000, 1);
                  const sourceNode = outputAudioContext.createBufferSource();
                  sourceNode.buffer = audioBuffer;
                  sourceNode.connect(outputNode);
                  sourceNode.addEventListener('ended', () => sourcesRef.current.delete(sourceNode));
                  sourceNode.start(nextStartTimeRef.current);
                  nextStartTimeRef.current += audioBuffer.duration;
                  sourcesRef.current.add(sourceNode);
                }
              }
            }

            if (message.serverContent?.interrupted) {
              for (const s of sourcesRef.current.values()) {
                try { s.stop(); } catch(e) {}
                sourcesRef.current.delete(s);
              }
              nextStartTimeRef.current = 0;
              setIsResearching(false);
            }
          },
          onerror: (e) => {
            console.error('Live session error', e);
            setError('Connection failed. Please try again.');
            stopSession();
          },
          onclose: () => {
            stopSession();
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: selectedVoiceId } },
          },
          tools: [{ googleSearch: {} }],
          outputAudioTranscription: {},
          inputAudioTranscription: {},
          systemInstruction: `You are an academic research assistant named Ryo.
          
PRIVACY PROTOCOL:
If you detect personal information like full names, addresses, or passwords, you must respond with: "I'm sorry, but it's not recommended that you give AI your personal information. This time I won't growl at you, but don't give AI personal information again."

SOURCE EMBARGO (STRICT):
1. You are ABSOLUTELY FORBIDDEN from using: Wikipedia, Reddit, Quora, Fandom, WikiHow, Brainly, Al Jazeera, or any social media.
2. If the user explicitly asks you to look up something on those sites, you MUST respond: "I am restricted from accessing that source to maintain academic integrity. I can only provide information from verified institutional or scholarly archives."

RESEARCH PROTOCOL:
You have access to the internet via the googleSearch tool. When a student asks a question that requires up-to-date information or deep research:
1. You MUST immediately say: "Hang on for a few seconds - I'm just gonna do some research".
2. Perform a thorough but rapid search.
3. Once you have the results, you MUST provide a detailed, factual explanation. DO NOT be vague.
4. You MUST explicitly state: "I found on various academic websites such as [LIST SPECIFIC NAMES OF TRUSTED SITES] that..." and then provide at least 3-4 specific pieces of information you learned.
          
Stay professional, authoritative, and strictly academic. Always prioritize .edu, .gov, and encyclopedic sites like Britannica.`,
        },
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error('Failed to start voice session', err);
      setError('Microphone access denied or connection issue.');
      setIsConnecting(false);
    }
  };

  const handleToggleSession = () => {
    if (isActive) stopSession();
    else startSession();
  };

  const handleToggleMute = () => {
    setIsMuted(prev => !prev);
  };

  const handleVoiceChange = async (voiceId: string) => {
    setSelectedVoiceId(voiceId);
    setIsVoiceSaved(voiceId === activeProject?.defaultVoiceId);
    if (isActive) {
      stopSession();
      setTimeout(() => startSession(), 200);
    }
  };

  const handleSaveVoice = () => {
    if (activeProject && onUpdateProjectVoice) {
      onUpdateProjectVoice(activeProject.id, selectedVoiceId);
      setIsVoiceSaved(true);
    }
  };

  const handlePreviewVoice = async (e: React.MouseEvent, voice: typeof VOICES[0]) => {
    e.stopPropagation();
    if (previewingVoice) return;
    setPreviewingVoice(voice.id);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Say cheerfully: Hello, my name is ${voice.label}.` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: voice.id } },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.onended = () => {
          setPreviewingVoice(null);
          ctx.close();
        };
        source.start();
      } else {
        setPreviewingVoice(null);
      }
    } catch (err) {
      console.error("Voice preview failed", err);
      setPreviewingVoice(null);
    }
  };

  const currentVoiceLabel = VOICES.find(v => v.id === selectedVoiceId)?.label || 'Ryo';

  useEffect(() => {
    return () => stopSession();
  }, []);

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 bg-slate-50 dark:bg-slate-950 relative overflow-hidden">
      <div className={`absolute inset-0 bg-indigo-600/5 transition-opacity duration-1000 ${isActive ? 'opacity-100' : 'opacity-0'}`}>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-400/20 rounded-full blur-[100px] animate-pulse" />
      </div>

      <div className="max-w-xl w-full flex flex-col items-center gap-12 z-10">
        <div className="text-center space-y-4">
          <div className="flex justify-center mb-4">
             <div className={`p-5 rounded-[2.5rem] transition-all duration-500 shadow-xl ${isActive ? (isMuted ? 'bg-amber-100 dark:bg-amber-950/30 text-amber-600 border border-amber-200 dark:border-amber-900/40' : 'bg-indigo-600 text-white scale-110') : 'bg-white dark:bg-slate-900 text-slate-400 dark:text-slate-600 border border-slate-100 dark:border-slate-800'}`}>
               {isActive ? (isMuted ? <MuteIcon size={48} /> : <Volume2 size={48} className={isResearching ? "" : "animate-pulse"} />) : <Mic size={48} />}
             </div>
          </div>
          <h2 className="text-3xl font-black text-slate-800 dark:text-slate-100">Voice Research Lab</h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Verified academic consultation via real-time spoken audio.</p>
        </div>

        <div className="w-full space-y-6 min-h-[220px] flex flex-col justify-center">
          {isResearching ? (
            <div className="flex flex-col items-center space-y-4 animate-in fade-in zoom-in-95">
              <div className="ryo-typing-indicator !h-auto !gap-2">
                <div className="ryo-dot !w-3 !h-3"></div>
                <div className="ryo-dot !w-3 !h-3 !delay-[-0.16s]"></div>
                <div className="ryo-dot !w-3 !h-3 !delay-[-0.32s]"></div>
              </div>
              <div className="flex flex-col items-center">
                <p className="text-sm font-black uppercase tracking-[0.2em] text-indigo-600 animate-pulse">
                  {RESEARCH_MESSAGES[statusIndex]}
                </p>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest mt-1">
                  Accessing Verified Knowledge...
                </p>
              </div>
            </div>
          ) : (
            <>
              {(inputTranscription || outputTranscription) && (
                <>
                  {inputTranscription && (
                    <div className="flex justify-end animate-in fade-in slide-in-from-right-4">
                      <div className="max-w-[80%] bg-indigo-100/50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-800 text-indigo-900 dark:text-indigo-200 px-6 py-3 rounded-2xl rounded-tr-none text-sm font-medium italic">
                        {inputTranscription}
                      </div>
                    </div>
                  )}
                  {outputTranscription && (
                    <div className="flex justify-start animate-in fade-in slide-in-from-left-4">
                      <div className="max-w-[80%] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 px-6 py-3 rounded-2xl rounded-tl-none text-sm leading-relaxed shadow-sm">
                        {outputTranscription}
                      </div>
                    </div>
                  )}
                </>
              )}
              {!isActive && !isConnecting && !error && (
                <div className="text-center py-8 px-6 bg-indigo-50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900 rounded-3xl animate-in fade-in zoom-in-95">
                  <ShieldCheck className="mx-auto text-indigo-500 mb-2" size={24} />
                  <p className="text-xs font-black uppercase tracking-widest text-indigo-600">Secure Consultation Ready</p>
                  <p className="text-slate-400 dark:text-slate-500 text-[11px] mt-1">Sessions are strictly anonymous and encrypted.</p>
                </div>
              )}
            </>
          )}
          {error && (
            <div className="bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900 text-red-600 dark:text-red-400 px-6 py-4 rounded-2xl text-sm font-bold text-center">
              {error}
            </div>
          )}
        </div>

        <div className="flex flex-col items-center gap-6 w-full">
          <div className="flex items-center gap-6">
            {isActive && (
              <button
                onClick={handleToggleMute}
                title={isMuted ? "Unmute Microphone" : "Mute Microphone"}
                className={`flex items-center justify-center w-16 h-16 rounded-full transition-all duration-300 shadow-lg ${
                  isMuted 
                    ? 'bg-amber-500 text-white hover:bg-amber-600' 
                    : 'bg-white dark:bg-slate-900 text-slate-400 dark:text-slate-500 border border-slate-200 dark:border-slate-800 hover:text-indigo-600 hover:border-indigo-200'
                }`}
              >
                {isMuted ? <MuteIcon size={24} /> : <Mic size={24} />}
              </button>
            )}

            <button
              onClick={handleToggleSession}
              disabled={isConnecting}
              className={`group relative flex items-center justify-center w-24 h-24 rounded-full transition-all duration-300 shadow-2xl ${
                isActive 
                  ? 'bg-red-500 text-white hover:bg-red-600 scale-105' 
                  : 'bg-indigo-600 text-white hover:bg-indigo-700 hover:scale-110'
              }`}
            >
              {isConnecting ? (
                <Loader2 size={32} className="animate-spin" />
              ) : isActive ? (
                <MicOff size={32} />
              ) : (
                <Mic size={32} />
              )}
              {isActive && !isResearching && !isMuted && (
                 <span className="absolute inset-0 rounded-full bg-red-500 animate-ping opacity-20 pointer-events-none" />
              )}
            </button>

            {isActive && <div className="w-16 h-16" />} {/* Spacer for layout balance */}
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowVoiceSettings(!showVoiceSettings)}
              className={`p-3 rounded-xl border transition-all flex items-center gap-2 text-sm font-bold ${
                showVoiceSettings ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-indigo-200'
              }`}
            >
              <Settings size={18} />
              Voice Profile
            </button>
            {isActive && (
              <div className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-black uppercase tracking-widest border transition-all ${isMuted ? 'bg-amber-50 dark:bg-amber-950/20 text-amber-600 border-amber-100 dark:border-amber-900' : 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 border-emerald-100 dark:border-emerald-900'}`}>
                <span className={`w-2 h-2 rounded-full ${isMuted ? 'bg-amber-500' : 'bg-emerald-500'} ${isResearching ? 'animate-bounce' : 'animate-pulse'}`} />
                {isMuted ? 'Muted' : `Live: ${currentVoiceLabel}`}
              </div>
            )}
          </div>
        </div>

        {showVoiceSettings && (
          <div className="absolute bottom-32 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl w-[320px] animate-in slide-in-from-bottom-4 duration-300">
            <h3 className="text-sm font-black uppercase tracking-widest text-slate-400 dark:text-slate-600 mb-4 flex items-center gap-2">
              <GraduationCap size={16} /> Speaker Profile
            </h3>
            <div className="grid grid-cols-1 gap-2 mb-6">
              {VOICES.map(v => (
                <div key={v.id} className="flex items-center gap-2 group/voice">
                  <button
                    onClick={() => handleVoiceChange(v.id)}
                    className={`flex-1 text-left px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                      selectedVoiceId === v.id 
                        ? 'bg-indigo-50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900' 
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-500 dark:text-slate-400 border border-transparent'
                    }`}
                  >
                    {v.label} {v.isDefault && <span className="text-[10px] ml-2 text-indigo-400">(Default)</span>}
                  </button>
                  <button
                    onClick={(e) => handlePreviewVoice(e, v)}
                    disabled={previewingVoice !== null}
                    title={`Preview ${v.label}`}
                    className={`p-3 rounded-xl border border-slate-100 dark:border-slate-700 text-indigo-500 hover:bg-indigo-600 hover:text-white transition-all shadow-sm ${previewingVoice === v.id ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-slate-800'}`}
                  >
                    {previewingVoice === v.id ? (
                      <Loader2 size={16} className="animate-spin" />
                    ) : (
                      <Volume1 size={16} />
                    )}
                  </button>
                </div>
              ))}
            </div>
            
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <button 
                onClick={handleSaveVoice}
                disabled={isVoiceSaved || !activeProject}
                className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                  isVoiceSaved 
                    ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 border border-emerald-100 dark:border-emerald-900' 
                    : 'bg-indigo-600 text-white shadow-lg hover:bg-indigo-700'
                }`}
              >
                {isVoiceSaved ? <Check size={16} /> : <Save size={16} />}
                {isVoiceSaved ? 'Saved to Project' : 'Save as Project Default'}
              </button>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium leading-relaxed px-1">Saving will remember this voice selection whenever you open the lab for this project.</p>
            </div>
          </div>
        )}
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-[10px] font-black uppercase tracking-[0.3em] text-slate-300 dark:text-slate-700 pointer-events-none">
        Native Neural Synthesis v2.5
      </div>
    </div>
  );
};

export default VoiceSession;
