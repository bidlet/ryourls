
import React, { useState } from 'react';
import { 
  Search as SearchIcon, 
  Mic, 
  Zap, 
  Globe, 
  BrainCircuit, 
  Menu, 
  X, 
  FolderOpen, 
  MessageSquare, 
  Plus, 
  Settings as SettingsIcon,
  ChevronRight,
  ChevronDown,
  Trash2,
  Edit3,
  Check,
  Search as SearchIconComponent
} from 'lucide-react';
import { Project, Chat, ViewType, AIPersonality } from '../types';

interface PhoneLayoutProps {
  view: ViewType;
  onSetView: (view: ViewType) => void;
  projects: Project[];
  chats: Chat[];
  activeProjectId: string | null;
  activeChatId: string | null;
  onNewProject: () => void;
  onNewChat: (projectId: string) => void;
  onSelectProject: (id: string) => void;
  onSelectChat: (id: string) => void;
  onOpenSettings: () => void;
  onRenameChat: (id: string, name: string) => void;
  onDeleteChat: (id: string) => void;
}

const PhoneLayout: React.FC<PhoneLayoutProps> = ({
  view,
  onSetView,
  projects,
  chats,
  activeProjectId,
  activeChatId,
  onNewProject,
  onNewChat,
  onSelectProject,
  onSelectChat,
  onOpenSettings,
  onRenameChat,
  onDeleteChat
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [expandedProjects, setExpandedProjects] = useState<Set<string>>(new Set());
  const [editingChatId, setEditingChatId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const navItems = [
    { id: 'research', icon: <SearchIcon size={20} />, label: 'Research', hash: '#/research' },
    { id: 'voice', icon: <Mic size={20} />, label: 'Voice', hash: '#/voice' },
    { id: 'brief', icon: <Zap size={20} />, label: 'Brief', hash: '#/brief' },
    { id: 'site-finder', icon: <Globe size={20} />, label: 'Finder', hash: '#/site-finder' },
    { id: 'flashcards', icon: <BrainCircuit size={20} />, label: 'Cards', hash: '#/flashcards' },
  ];

  const toggleProject = (id: string) => {
    const next = new Set(expandedProjects);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setExpandedProjects(next);
  };

  const startEditingChat = (c: Chat) => {
    setEditingChatId(c.id);
    setEditName(c.name);
  };

  const saveEditChat = (id: string) => {
    if (editName.trim()) onRenameChat(id, editName);
    setEditingChatId(null);
  };

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-[150] p-5 pointer-events-none">
      <div className="flex items-center gap-5 max-w-md mx-auto pointer-events-auto">
        {/* Hamburger Menu Button */}
        <button 
          onClick={() => setIsMenuOpen(true)}
          className="w-14 h-14 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl rounded-2xl flex items-center justify-center text-indigo-600 active:scale-95 transition-all"
        >
          <Menu size={24} />
        </button>

        {/* Floating Bottom Navbar */}
        <nav className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl rounded-2xl h-14 px-2 flex items-center justify-around overflow-hidden">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onSetView(item.id as ViewType);
                window.location.hash = item.hash;
              }}
              className={`flex flex-col items-center justify-center transition-all ${
                view === item.id ? 'text-indigo-600 scale-110' : 'text-slate-400 dark:text-slate-600'
              }`}
            >
              {item.icon}
              <span className="text-[8px] font-bold uppercase tracking-widest mt-0.5">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Fullscreen Sidebar Popup */}
      {isMenuOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[200] flex flex-col animate-in fade-in duration-300 pointer-events-auto">
          <div className="bg-white dark:bg-slate-900 w-full h-[85vh] mt-auto rounded-t-[2.5rem] flex flex-col overflow-hidden animate-in slide-in-from-bottom-full duration-500">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <FolderOpen className="text-indigo-600" />
                Your Archive
              </h2>
              <button onClick={() => setIsMenuOpen(false)} className="p-2 bg-slate-50 dark:bg-slate-800 rounded-xl text-slate-400">
                <X size={24} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
              <div className="px-2 pb-2">
                <button 
                  onClick={() => { setIsMenuOpen(false); /* Trigger search via event if needed */ }}
                  className="w-full flex items-center gap-3 px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-2xl text-slate-400 text-sm font-medium"
                >
                  <SearchIconComponent size={18} />
                  <span>Search your research...</span>
                </button>
              </div>

              <div className="flex items-center justify-between px-2 text-xs font-bold text-slate-400 dark:text-slate-600 uppercase tracking-widest">
                <span>Projects</span>
                <button onClick={onNewProject} className="p-1 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 rounded-lg">
                  <Plus size={16} />
                </button>
              </div>

              {projects.map((project) => (
                <div key={project.id} className="space-y-1">
                  <button 
                    onClick={() => { toggleProject(project.id); onSelectProject(project.id); }}
                    className={`w-full flex items-center gap-3 px-3 py-3 rounded-2xl text-sm font-semibold transition-all ${
                      activeProjectId === project.id ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-400' : 'text-slate-600 dark:text-slate-400 active:bg-slate-50 dark:active:bg-slate-800/50'
                    }`}
                  >
                    {expandedProjects.has(project.id) ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    <FolderOpen size={18} className={activeProjectId === project.id ? 'text-indigo-500' : 'text-slate-400 dark:text-slate-700'} />
                    <span className="flex-1 text-left truncate">{project.name}</span>
                    <button 
                      onClick={(e) => { e.stopPropagation(); onNewChat(project.id); setIsMenuOpen(false); }}
                      className="p-1 text-indigo-400"
                    >
                      <Plus size={16} />
                    </button>
                  </button>

                  {expandedProjects.has(project.id) && (
                    <div className="ml-6 space-y-1 border-l border-slate-100 dark:border-slate-800 pl-4 py-1">
                      {chats.filter(c => c.projectId === project.id).map(chat => (
                        <div key={chat.id} className="group flex items-center">
                          <button 
                            onClick={() => { onSelectChat(chat.id); setIsMenuOpen(false); }}
                            className={`flex-1 flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-medium text-left truncate ${
                              activeChatId === chat.id ? 'bg-white dark:bg-slate-800 border border-indigo-100 dark:border-indigo-900 text-indigo-700 dark:text-indigo-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 active:bg-slate-50 dark:active:bg-slate-800/30'
                            }`}
                          >
                            <MessageSquare size={14} className={activeChatId === chat.id ? 'text-indigo-500' : 'text-slate-300 dark:text-slate-700'} />
                            {editingChatId === chat.id ? (
                              <div className="flex items-center gap-1 flex-1 min-w-0" onClick={e => e.stopPropagation()}>
                                <input autoFocus className="w-full bg-slate-50 dark:bg-slate-700 border dark:border-slate-600 rounded px-1.5 py-0.5 dark:text-slate-100" value={editName} onChange={e => setEditName(e.target.value)} onKeyDown={e => e.key === 'Enter' && saveEditChat(chat.id)} />
                                <button onClick={() => saveEditChat(chat.id)} className="text-emerald-500"><Check size={14}/></button>
                              </div>
                            ) : <span className="truncate">{chat.name}</span>}
                          </button>
                          <div className="flex gap-1 ml-1">
                            <button onClick={() => startEditingChat(chat)} className="p-2 text-slate-300 dark:text-slate-600"><Edit3 size={14}/></button>
                            <button onClick={() => onDeleteChat(chat.id)} className="p-2 text-slate-300 dark:text-slate-600"><Trash2 size={14}/></button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="p-6 bg-slate-50 dark:bg-slate-950/50 border-t border-slate-100 dark:border-slate-800">
              <button 
                onClick={() => { onOpenSettings(); setIsMenuOpen(false); }}
                className="w-full flex items-center justify-center gap-3 py-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-slate-700 dark:text-slate-300 font-bold active:bg-slate-100 dark:active:bg-slate-700 transition-all"
              >
                <SettingsIcon size={20} />
                Integrity Vault
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PhoneLayout;
