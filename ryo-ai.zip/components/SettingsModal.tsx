
import React, { useState } from 'react';
import { X, Settings as SettingsIcon, ShieldX, UserCheck, ShieldCheck, AlertCircle, History, RotateCcw, Trash, Database, Moon, Sun, MessageSquareText } from 'lucide-react';
import { UserSettings, AIPersonality, Chat } from '../types';

interface SettingsModalProps {
  settings: UserSettings;
  onSave: (settings: UserSettings) => void;
  onClose: () => void;
  deletedChats?: Chat[];
  onRestoreChat?: (chatId: string) => void;
  onClearVault?: () => void;
}

const personalities: AIPersonality[] = ['Academic', 'Encouraging', 'Concise', 'Socratic'];

const SettingsModal: React.FC<SettingsModalProps> = ({ settings, onSave, onClose, deletedChats = [], onRestoreChat, onClearVault }) => {
  const [localSettings, setLocalSettings] = useState<UserSettings>({ ...settings });
  const [activeTab, setActiveTab] = useState<'guards' | 'recovery'>('guards');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3 text-indigo-600 font-bold text-lg">
            <SettingsIcon size={24} />
            Integrity Center
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X size={24} />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-50 dark:border-slate-800">
          <button 
            onClick={() => setActiveTab('guards')}
            className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'guards' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/30 dark:bg-indigo-950/20' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Integrity Guards
          </button>
          <button 
            onClick={() => setActiveTab('recovery')}
            className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${activeTab === 'recovery' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/30 dark:bg-indigo-950/20' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Recovery Vault
            {deletedChats.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[10px] animate-pulse">
                {deletedChats.length}
              </span>
            )}
          </button>
        </div>

        <div className="p-6 space-y-8 max-h-[60vh] overflow-y-auto no-scrollbar">
          {activeTab === 'guards' ? (
            <>
              {/* Visual Theme Selection */}
              <section>
                <div className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-100 mb-4 uppercase tracking-widest">
                  <Sun size={16} className="text-amber-500" />
                  Visual Interface
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { id: 'light', label: 'Light Mode', icon: <Sun size={18} /> },
                    { id: 'dark', label: 'Dark Mode', icon: <Moon size={18} /> }
                  ].map(theme => (
                    <button
                      key={theme.id}
                      onClick={() => setLocalSettings({ ...localSettings, theme: theme.id as 'light' | 'dark' })}
                      className={`flex items-center justify-center gap-2 px-4 py-4 rounded-xl border text-sm font-bold transition-all ${
                        localSettings.theme === theme.id
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-100 dark:shadow-indigo-900/40'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-indigo-200'
                      }`}
                    >
                      {theme.icon}
                      {theme.label}
                    </button>
                  ))}
                </div>
              </section>

              {/* Strict Filter Toggle */}
              <section>
                <div className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-100 mb-4 uppercase tracking-widest">
                  <ShieldCheck size={16} className="text-emerald-500" />
                  Access Protocols
                </div>
                <button 
                  onClick={() => setLocalSettings({ ...localSettings, strictFilterEnabled: !localSettings.strictFilterEnabled })}
                  className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all ${
                    localSettings.strictFilterEnabled 
                      ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300' 
                      : 'bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {localSettings.strictFilterEnabled ? <ShieldCheck className="shrink-0" /> : <AlertCircle className="shrink-0" />}
                    <div className="text-left">
                      <div className="font-bold text-sm">Strict Wiki Embargo</div>
                      <div className="text-xs opacity-70">Block user-edited sites (Wiki, Reddit, etc).</div>
                    </div>
                  </div>
                  <div className={`w-12 h-6 rounded-full relative transition-colors ${localSettings.strictFilterEnabled ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'}`}>
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${localSettings.strictFilterEnabled ? 'right-1' : 'left-1'}`} />
                  </div>
                </button>
              </section>

              {/* Personality */}
              <section>
                <div className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-100 mb-4 uppercase tracking-widest">
                  <UserCheck size={16} className="text-indigo-500" />
                  Cognitive Persona
                </div>
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {personalities.map(p => (
                    <button
                      key={p}
                      onClick={() => setLocalSettings({ ...localSettings, personality: p })}
                      className={`px-4 py-3 rounded-xl border text-sm font-medium transition-all ${
                        localSettings.personality === p
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-100'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-indigo-200'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">
                    <MessageSquareText size={14} className="text-indigo-400" />
                    Custom Personality Instructions
                  </div>
                  <textarea 
                    value={localSettings.customPersonality || ''}
                    onChange={(e) => setLocalSettings({ ...localSettings, customPersonality: e.target.value })}
                    placeholder="e.g., Be very critiquing of what I say. When I ask if I should do something, give me both the positives and negatives clearly."
                    className="w-full min-h-[120px] p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 dark:text-slate-100 resize-none transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                  />
                  <p className="text-[10px] text-slate-400 italic">These instructions will be appended to Ryo's core logic for every interaction.</p>
                </div>
              </section>
            </>
          ) : (
            <section className="animate-in fade-in slide-in-from-right-4 duration-300">
               <div className="flex items-center justify-between mb-6">
                 <div className="flex items-center gap-2 text-sm font-bold text-slate-700 dark:text-slate-100 uppercase tracking-widest">
                    <Database size={16} className="text-indigo-500" />
                    Recently Deleted
                 </div>
                 {deletedChats.length > 0 && (
                   <button 
                     onClick={onClearVault}
                     className="text-[10px] font-black uppercase text-red-500 hover:text-red-700 tracking-wider flex items-center gap-1"
                   >
                     <Trash size={12} /> Purge All
                   </button>
                 )}
               </div>

               <div className="space-y-3">
                 {deletedChats.length === 0 ? (
                   <div className="flex flex-col items-center justify-center py-12 text-center text-slate-400">
                      <History size={48} className="opacity-10 mb-4" />
                      <p className="text-sm font-medium">Vault is currently empty.</p>
                      <p className="text-xs opacity-60">Deleted chats will appear here for 30 days.</p>
                   </div>
                 ) : (
                   deletedChats.map(chat => (
                     <div key={chat.id} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 rounded-2xl group transition-all hover:bg-white dark:hover:bg-slate-800 hover:shadow-md">
                        <div className="min-w-0">
                           <div className="text-sm font-bold text-slate-700 dark:text-slate-200 truncate">{chat.name}</div>
                           <div className="text-[10px] text-slate-400 uppercase tracking-tighter">
                             Deleted {chat.deletedAt ? new Date(chat.deletedAt).toLocaleDateString() : 'recently'}
                           </div>
                        </div>
                        <button 
                          onClick={() => onRestoreChat?.(chat.id)}
                          className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-900 border border-indigo-100 dark:border-indigo-900 rounded-xl text-indigo-600 text-xs font-bold shadow-sm hover:bg-indigo-600 hover:text-white transition-all"
                        >
                          <RotateCcw size={14} /> Restore
                        </button>
                     </div>
                   ))
                 )}
               </div>
            </section>
          )}
        </div>

        <div className="p-6 bg-slate-50 dark:bg-slate-950/50 border-t border-slate-100 dark:border-slate-800 flex gap-3">
          <button onClick={onClose} className="flex-1 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">Close</button>
          <button onClick={() => { onSave(localSettings); onClose(); }} className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-100">Apply Changes</button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
