
import React, { useState } from 'react';
import { generateFlashcards } from '../services/geminiService';
import { FlashcardSet, UserSettings } from '../types';
import InteractiveText from './InteractiveText';
import { Sparkles, Loader2, RotateCw, ExternalLink, ShieldCheck, GraduationCap, History, Trash2, Save, CheckCircle2, BookOpenCheck, ChevronDown, ChevronUp } from 'lucide-react';

interface FlashcardSessionProps {
  settings: UserSettings;
  savedSets: FlashcardSet[];
  onSaveSet: (set: FlashcardSet) => void;
  onDeleteSet: (id: string) => void;
}

const FlashcardSession: React.FC<FlashcardSessionProps> = ({ settings, savedSets, onSaveSet, onDeleteSet }) => {
  const [topic, setTopic] = useState('');
  const [wordLimit, setWordLimit] = useState(50);
  const [isLoading, setIsLoading] = useState(false);
  const [activeSet, setActiveSet] = useState<FlashcardSet | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [showSources, setShowSources] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    setIsLoading(true);
    setActiveSet(null);
    setCurrentIndex(0);
    setIsFlipped(false);
    setIsSaved(false);
    setShowSources(false);

    try {
      const data = await generateFlashcards(topic, wordLimit, settings);
      setActiveSet(data);
    } catch (error: any) {
      alert(error.message || "Integrity Error: Could not generate wiki-free flashcards.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveSet = () => {
    if (activeSet && !isSaved) {
      onSaveSet(activeSet);
      setIsSaved(true);
    }
  };

  const nextCard = () => {
    if (!activeSet) return;
    if (currentIndex < activeSet.cards.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setIsFlipped(false);
    } else {
      // Go to summary
      setCurrentIndex(activeSet.cards.length);
    }
  };

  const prevCard = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setIsFlipped(false);
    }
  };

  const handleSelectSaved = (set: FlashcardSet) => {
    setActiveSet(set);
    setCurrentIndex(0);
    setIsFlipped(false);
    setIsSaved(true);
    setShowSources(false);
  };

  const handleNewSession = () => {
    setActiveSet(null);
    setIsSaved(false);
  };

  return (
    <div className="flex h-full w-full overflow-hidden bg-slate-50 dark:bg-slate-950">
      {/* Sidebar for History */}
      <aside className="w-64 bg-slate-50 dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 hidden md:flex flex-col p-4 shrink-0">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-400 dark:text-slate-600 uppercase tracking-widest mb-4">
          <History size={14} /> Flashcard Vault
        </div>
        <div className="flex-1 overflow-y-auto space-y-2 no-scrollbar">
          {savedSets.map(set => (
            <div key={set.id} className="group relative">
              <button 
                onClick={() => handleSelectSaved(set)}
                className={`w-full text-left p-3 rounded-xl text-sm transition-all border ${
                  activeSet?.id === set.id 
                  ? 'bg-white dark:bg-slate-800 border-indigo-200 dark:border-indigo-900 text-indigo-700 dark:text-indigo-400 shadow-sm font-semibold' 
                  : 'bg-transparent border-transparent text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/50'
                }`}
              >
                <div className="truncate pr-6">{set.topic}</div>
                <div className="text-[10px] text-slate-400 dark:text-slate-600 mt-1">
                  {new Date(set.createdAt).toLocaleDateString()}
                </div>
              </button>
              <button 
                onClick={(e) => { e.stopPropagation(); onDeleteSet(set.id); if(activeSet?.id === set.id) handleNewSession(); }}
                className="absolute right-2 top-3 p-1 text-slate-300 dark:text-slate-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
          {savedSets.length === 0 && <p className="text-xs text-slate-400 dark:text-slate-600 italic text-center p-4">No cards saved yet.</p>}
        </div>
      </aside>

      <div className="flex-1 overflow-y-auto p-4 md:p-8 flex flex-col items-center no-scrollbar relative">
        {!activeSet && !isLoading ? (
          <div className="max-w-xl w-full mt-12 bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-indigo-900/10">
            <div className="flex items-center gap-3 text-indigo-600 mb-6">
              <GraduationCap size={32} />
              <h2 className="text-2xl font-bold dark:text-slate-100">Study Flashcards</h2>
            </div>
            <form onSubmit={handleGenerate} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Topic or Subject</label>
                <input
                  type="text"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="e.g., Photosynthesis, The Cold War..."
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2 flex justify-between">
                  <span>Explanation Depth</span>
                  <span className="text-indigo-600 font-bold">~{wordLimit} words per card</span>
                </label>
                <input
                  type="range" min="20" max="250" step="10" value={wordLimit}
                  onChange={(e) => setWordLimit(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400 dark:text-slate-600 mt-1 font-bold uppercase tracking-tighter">
                   <span>Basic</span>
                   <span>Detailed</span>
                   <span>Deep Dive</span>
                </div>
              </div>
              <button
                type="submit"
                disabled={!topic.trim()}
                className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold shadow-lg shadow-indigo-200 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
              >
                <Sparkles size={20} />
                Generate Academic Cards
              </button>
            </form>
          </div>
        ) : isLoading ? (
          <div className="flex flex-col items-center justify-center mt-32 space-y-4">
            <div className="relative">
               <div className="w-20 h-20 border-4 border-indigo-100 dark:border-indigo-900 border-t-indigo-600 rounded-full animate-spin" />
               <Loader2 size={32} className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-indigo-600 animate-pulse" />
            </div>
            <p className="text-slate-500 dark:text-slate-400 font-medium animate-pulse text-center">Researching Non-Wiki Sources...</p>
          </div>
        ) : (
          <div className="max-w-2xl w-full flex flex-col items-center pb-24">
            <div className="w-full mb-8 flex items-center justify-between">
              <button onClick={handleNewSession} className="text-sm font-semibold text-slate-500 dark:text-slate-400 hover:text-indigo-600">← Back</button>
              <div className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest truncate max-w-[200px]">{activeSet?.topic}</div>
              <button 
                onClick={() => setShowSources(!showSources)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                  showSources ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 border-indigo-100 dark:border-indigo-900 hover:border-indigo-200'
                }`}
              >
                <BookOpenCheck size={14} />
                {showSources ? 'Hide Sources' : 'View Sources'}
              </button>
            </div>

            {showSources && activeSet && (
              <div className="w-full mb-8 animate-in slide-in-from-top-4 duration-300">
                <div className="bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900 rounded-2xl p-6">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-widest mb-4">
                    <ShieldCheck size={14} /> Verified Citations for this Set
                  </div>
                  <div className="grid gap-2">
                    {activeSet.sources.map((s, idx) => (
                      <div 
                        key={idx} 
                        className="flex items-center justify-between p-3 bg-white dark:bg-slate-900 border border-emerald-100 dark:border-emerald-900 rounded-xl transition-colors group"
                      >
                        <span className="text-sm font-bold text-slate-700 dark:text-slate-200 truncate">{s.title}</span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <a href={s.uri} target="_blank" rel="noreferrer" className="p-1.5 text-slate-400 hover:text-indigo-600">
                            <ExternalLink size={12} />
                          </a>
                        </div>
                      </div>
                    ))}
                    {activeSet.sources.length === 0 && <p className="text-xs text-slate-500 dark:text-slate-400 italic">No external sources were needed for this common factual set.</p>}
                  </div>
                </div>
              </div>
            )}

            {currentIndex < activeSet!.cards.length ? (
              <div className="w-full space-y-8">
                <div onClick={() => setIsFlipped(!isFlipped)} className="relative w-full aspect-[4/3] md:aspect-[16/9] perspective-1000 cursor-pointer group">
                  <div className={`relative w-full h-full transition-all duration-500 preserve-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
                    {/* Front */}
                    <div className="absolute inset-0 backface-hidden bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 rounded-[2rem] shadow-xl p-8 flex flex-col items-center justify-center text-center">
                      <div className="text-sm font-bold text-indigo-500 uppercase tracking-widest mb-4">Question</div>
                      <h3 className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-slate-100 leading-tight">{activeSet!.cards[currentIndex].front}</h3>
                      <div className="mt-8 text-slate-400 dark:text-slate-600 flex items-center gap-2 text-xs bg-slate-50 dark:bg-slate-800/50 px-3 py-1.5 rounded-full"><RotateCw size={14} /> Click to reveal answer</div>
                    </div>
                    {/* Back */}
                    <div className="absolute inset-0 backface-hidden rotate-y-180 bg-indigo-600 text-white rounded-[2rem] shadow-xl p-8 flex flex-col items-center justify-center text-center overflow-y-auto no-scrollbar">
                      <div className="text-sm font-bold text-indigo-200 uppercase tracking-widest mb-4">Academic Insight</div>
                      <InteractiveText text={activeSet!.cards[currentIndex].back} className="text-lg md:text-xl leading-relaxed" />
                    </div>
                  </div>
                </div>
                <div className="w-full flex items-center justify-between gap-4">
                  <button onClick={prevCard} disabled={currentIndex === 0} className="flex-1 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 disabled:opacity-30 font-semibold transition-colors">Previous</button>
                  <div className="text-slate-400 dark:text-slate-600 font-bold px-4 text-sm">{currentIndex + 1} / {activeSet!.cards.length}</div>
                  <button onClick={nextCard} className="flex-1 py-4 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 font-semibold shadow-lg shadow-indigo-100 transition-all">
                    {currentIndex === activeSet!.cards.length - 1 ? 'Finish Session' : 'Next Card'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2rem] shadow-xl p-8 md:p-12 text-center animate-in zoom-in-95 duration-500">
                 <ShieldCheck size={48} className="text-emerald-500 mx-auto mb-6" />
                 <h3 className="text-3xl font-bold text-slate-800 dark:text-slate-100 mb-4">Session Mastery Reached</h3>
                 <p className="text-slate-500 dark:text-slate-400 mb-8">You have successfully reviewed this study set. Every card was generated using high-integrity research methods.</p>
                 
                 {/* Final Summary of Sources - Ensure it is clear and prominent */}
                 <div className="mb-8 text-left bg-emerald-50/50 dark:bg-emerald-950/20 p-6 rounded-2xl border border-emerald-100 dark:border-emerald-900 shadow-inner">
                    <div className="text-xs font-black text-emerald-700 dark:text-emerald-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                      <BookOpenCheck size={14} /> Source Verification Log
                    </div>
                    <div className="space-y-3">
                       {activeSet?.sources && activeSet.sources.length > 0 ? activeSet.sources.map((s, idx) => (
                         <div key={idx} className="flex items-center justify-between gap-2 text-sm text-slate-700 dark:text-slate-300">
                            <div className="flex items-center gap-2 truncate">
                              <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                              <span className="truncate font-semibold">{s.title}</span>
                            </div>
                            <a href={s.uri} target="_blank" rel="noreferrer" className="text-indigo-600 dark:text-indigo-400">
                              <ExternalLink size={12} />
                            </a>
                         </div>
                       )) : (
                         <p className="text-xs italic text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-100 dark:border-slate-800">Foundational academic facts verified across multiple institutional databases. No direct external link required for this verified common knowledge set.</p>
                       )}
                    </div>
                 </div>

                 <div className="flex flex-col sm:flex-row gap-4">
                    <button 
                      onClick={handleSaveSet} 
                      disabled={isSaved}
                      className={`flex-1 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all ${
                        isSaved ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 border border-emerald-100 dark:border-emerald-900' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-100'
                      }`}
                    >
                      {isSaved ? <CheckCircle2 size={20} /> : <Save size={20} />}
                      {isSaved ? 'Saved to Vault' : 'Save Set'}
                    </button>
                    <button 
                      onClick={handleNewSession} 
                      className="flex-1 py-4 font-bold rounded-2xl transition-colors bg-slate-800 dark:bg-slate-700 text-white hover:bg-slate-900 dark:hover:bg-slate-600"
                    >
                      New Topic
                    </button>
                 </div>
              </div>
            )}
          </div>
        )}
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .perspective-1000 { perspective: 1000px; }
        .preserve-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
      `}} />
    </div>
  );
};

export default FlashcardSession;
