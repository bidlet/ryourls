
import React, { useState, useEffect, useRef } from 'react';
import { Type, Eye, Palette, Check, X, Mic, MicOff, AlignLeft, ArrowRightLeft, MousePointer, ExternalLink, Focus, Ghost, Layout, Paintbrush, MonitorOff, Timer, BookText, Play, Square, RotateCcw, Loader2, GripHorizontal, Minus, Plus, RefreshCw } from 'lucide-react';
import { AccessibilitySettings, ScreenOverlayType, Chat } from '../types';
import { summarizeChat } from '../services/geminiService';

interface AccessibilityFabProps {
  settings: AccessibilitySettings;
  onUpdate: (settings: AccessibilitySettings) => void;
  isInputView: boolean;
  activeChat?: Chat | null;
}

const fireConfetti = () => {
  const canvas = document.createElement('canvas');
  canvas.style.position = 'fixed';
  canvas.style.top = '0';
  canvas.style.left = '0';
  canvas.style.width = '100%';
  canvas.style.height = '100%';
  canvas.style.pointerEvents = 'none';
  canvas.style.zIndex = '10000';
  document.body.appendChild(canvas);

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  const particles: any[] = [];
  const colors = ['#4f46e5', '#818cf8', '#fbbf24', '#f87171', '#34d399'];

  for (let i = 0; i < 150; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: -20,
      r: Math.random() * 6 + 4,
      d: Math.random() * 150,
      color: colors[Math.floor(Math.random() * colors.length)],
      tilt: Math.floor(Math.random() * 10) - 10,
      tiltAngleIncremental: (Math.random() * 0.07) + 0.05,
      tiltAngle: 0
    });
  }

  let animationFrame: number;
  const draw = () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach((p, i) => {
      p.tiltAngle += p.tiltAngleIncremental;
      p.y += (Math.cos(p.d) + 3 + p.r / 2) / 2;
      p.tilt = Math.sin(p.tiltAngle) * 15;

      ctx.beginPath();
      ctx.lineWidth = p.r;
      ctx.strokeStyle = p.color;
      ctx.moveTo(p.x + p.tilt + p.r / 2, p.y);
      ctx.lineTo(p.x + p.tilt, p.y + p.tilt + p.r / 2);
      ctx.stroke();

      if (p.y > canvas.height) {
        particles[i].y = -20;
        particles[i].x = Math.random() * canvas.width;
      }
    });

    animationFrame = requestAnimationFrame(draw);
  };

  draw();

  setTimeout(() => {
    cancelAnimationFrame(animationFrame);
    canvas.remove();
  }, 5000);
};

const DraggableTimer: React.FC<{ focusTime: number, breakTime: number, onClose: () => void }> = ({ focusTime, breakTime, onClose }) => {
  const [timeLeft, setTimeLeft] = useState(focusTime * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [position, setPosition] = useState({ x: window.innerWidth / 2 - 100, y: window.innerHeight - 120 });
  const [isDragging, setIsDragging] = useState(false);
  const timerRef = useRef<number | null>(null);
  const offsetRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    if (position.y === 0) setPosition({ x: window.innerWidth / 2 - 100, y: window.innerHeight - 120 });
  }, []);

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = window.setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      // Timer finished! Fire confetti
      fireConfetti();
      
      if (mode === 'focus') {
        setMode('break');
        setTimeLeft(breakTime * 60);
      } else {
        setMode('focus');
        setTimeLeft(focusTime * 60);
      }
      setIsActive(false);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isActive, timeLeft, mode, focusTime, breakTime]);

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setMode('focus');
    setTimeLeft(focusTime * 60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    offsetRef.current = {
      x: e.clientX - position.x,
      y: e.clientY - position.y
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        setPosition({
          x: e.clientX - offsetRef.current.x,
          y: e.clientY - offsetRef.current.y
        });
      }
    };
    const handleMouseUp = () => setIsDragging(false);

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  return (
    <div 
      className="fixed z-[300] w-52 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden select-none"
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
    >
      <div 
        onMouseDown={handleMouseDown}
        className="h-8 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800 flex items-center justify-center cursor-grab active:cursor-grabbing text-slate-300 hover:text-indigo-400 transition-colors"
      >
        <GripHorizontal size={16} />
      </div>
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className={`text-[10px] font-black uppercase tracking-widest ${mode === 'focus' ? 'text-indigo-500' : 'text-emerald-500'}`}>
            {mode === 'focus' ? 'Deep Focus' : 'Short Break'}
          </span>
          <button onClick={onClose} className="text-slate-300 hover:text-red-500 transition-colors">
            <X size={14} />
          </button>
        </div>
        <div className="text-3xl font-black text-slate-800 dark:text-slate-100 text-center py-1">
          {formatTime(timeLeft)}
        </div>
        <div className="flex gap-2">
          <button 
            onClick={toggleTimer} 
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all shadow-sm ${
              isActive ? 'bg-amber-500 text-white' : 'bg-indigo-600 text-white'
            }`}
          >
            {isActive ? <Square size={14} /> : <Play size={14} />}
            {isActive ? 'Pause' : 'Start'}
          </button>
          <button 
            onClick={resetTimer} 
            className="p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-400 hover:text-indigo-600 transition-all"
          >
            <RotateCcw size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

const AccessibilityFab: React.FC<AccessibilityFabProps> = ({ settings, onUpdate, isInputView, activeChat }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [summaryWordCount, setSummaryWordCount] = useState(100);
  const [focusMins, setFocusMins] = useState(25);
  const [breakMins, setBreakMins] = useState(5);

  const positionClasses = isInputView 
    ? "bottom-[120px] right-[6.125rem] md:bottom-[130px] md:right-[6.625rem]" 
    : "bottom-5 right-[5.875rem]";

  const toggle = (field: keyof AccessibilitySettings) => {
    onUpdate({ ...settings, [field]: !settings[field] });
  };

  const toggleFontType = () => {
    onUpdate({ 
      ...settings, 
      dyslexiaFontType: settings.dyslexiaFontType === 'open' ? 'lexend' : 'open' 
    });
  };

  const setNumeric = (field: keyof AccessibilitySettings, val: number) => {
    onUpdate({ ...settings, [field]: val });
  };

  const setOverlay = (val: ScreenOverlayType) => {
    onUpdate({ ...settings, screenOverlay: val });
  };

  const handleSummarize = async () => {
    if (!activeChat || activeChat.messages.length === 0) return;
    setIsSummarizing(true);
    try {
      const res = await summarizeChat(activeChat, summaryWordCount);
      setSummary(res);
    } catch (e) {
      setSummary("Academic complexity exceeded threshold. Try a simpler session.");
    } finally {
      setIsSummarizing(false);
    }
  };

  return (
    <>
      {settings.pomodoroEnabled && (
        <DraggableTimer 
          focusTime={focusMins} 
          breakTime={breakMins} 
          onClose={() => toggle('pomodoroEnabled')} 
        />
      )}

      <div className={`fixed z-[250] flex flex-col items-end gap-3 pointer-events-none transition-all duration-500 ease-in-out ${positionClasses}`}>
        {isOpen && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] shadow-2xl p-6 w-80 max-h-[75vh] overflow-y-auto no-scrollbar animate-in slide-in-from-bottom-4 duration-300 pointer-events-auto">
            <div className="flex items-center justify-between mb-4 px-1">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-600">Accessibility Lab</h3>
              <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={16}/></button>
            </div>

            <div className="space-y-6">
              {/* Summary Tool */}
              <div className="space-y-3">
                <span className="text-[10px] font-black uppercase tracking-widest text-indigo-500 block px-1 flex items-center gap-2">
                  <BookText size={12} /> Researcher Briefing
                </span>
                
                <div className="px-1 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Summary Length</span>
                    <span className="text-[10px] text-indigo-600 font-black">{summaryWordCount} words</span>
                  </div>
                  <input 
                    type="range" 
                    min="20" 
                    max="500" 
                    step="10" 
                    value={summaryWordCount}
                    onChange={(e) => setSummaryWordCount(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                  />
                  <div className="flex justify-between text-[8px] font-bold text-slate-300 dark:text-slate-600 uppercase">
                    <span>Short</span>
                    <span>Standard</span>
                    <span>Detailed</span>
                  </div>
                </div>

                {!summary ? (
                  <button 
                    onClick={handleSummarize}
                    disabled={!activeChat || activeChat.messages.length === 0 || isSummarizing}
                    className="w-full flex items-center justify-center gap-3 px-4 py-3 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900 rounded-xl text-xs font-bold hover:bg-indigo-600 hover:text-white transition-all disabled:opacity-50"
                  >
                    {isSummarizing ? <Loader2 size={16} className="animate-spin" /> : <BookText size={16} />}
                    Generate Executive Summary
                  </button>
                ) : (
                  <div className="p-4 bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900 rounded-2xl space-y-3 animate-in fade-in zoom-in-95">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-black uppercase tracking-widest text-indigo-600">Session Digest</span>
                      <button onClick={() => setSummary(null)} className="text-indigo-400 hover:text-indigo-600"><X size={12} /></button>
                    </div>
                    <p className="text-[11px] leading-relaxed text-slate-700 dark:text-slate-300 whitespace-pre-wrap italic">
                      {summary}
                    </p>
                  </div>
                )}
              </div>

              {/* Pomodoro Configuration */}
              <div className="space-y-3">
                <span className="text-[10px] font-black uppercase tracking-widest text-indigo-500 block px-1 flex items-center gap-2">
                  <Timer size={12} /> Focus Intervals
                </span>
                
                <div className="grid grid-cols-2 gap-3 px-1">
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Focus (Min)</label>
                    <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 p-2 rounded-xl border border-slate-100 dark:border-slate-700">
                      <button onClick={() => setFocusMins(Math.max(1, focusMins - 1))} className="text-slate-400"><Minus size={12}/></button>
                      <input type="number" value={focusMins} onChange={(e) => setFocusMins(parseInt(e.target.value) || 25)} className="w-full bg-transparent text-center text-xs font-bold text-slate-700 dark:text-slate-200 outline-none" />
                      <button onClick={() => setFocusMins(focusMins + 1)} className="text-slate-400"><Plus size={12}/></button>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Break (Min)</label>
                    <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 p-2 rounded-xl border border-slate-100 dark:border-slate-700">
                      <button onClick={() => setBreakMins(Math.max(1, breakMins - 1))} className="text-slate-400"><Minus size={12}/></button>
                      <input type="number" value={breakMins} onChange={(e) => setBreakMins(parseInt(e.target.value) || 5)} className="w-full bg-transparent text-center text-xs font-bold text-slate-700 dark:text-slate-200 outline-none" />
                      <button onClick={() => setBreakMins(breakMins + 1)} className="text-slate-400"><Plus size={12}/></button>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => toggle('pomodoroEnabled')}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-all border ${
                    settings.pomodoroEnabled ? 'bg-indigo-600 text-white' : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-500'
                  }`}
                >
                  {settings.pomodoroEnabled ? 'Hide Floating Timer' : 'Show Floating Timer'}
                  {settings.pomodoroEnabled && <Check size={14} />}
                </button>
              </div>

              {/* ADHD Focus Suite */}
              <div className="space-y-3">
                <span className="text-[10px] font-black uppercase tracking-widest text-indigo-500 block px-1 flex items-center gap-2">
                  <Focus size={12} /> ADHD Focus Suite
                </span>
                
                <div className="grid grid-cols-1 gap-2">
                  <button 
                    onClick={() => toggle('readingMask')}
                    className={`flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-all border ${
                      settings.readingMask ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-500'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Ghost size={14} /> Reading Mask
                    </div>
                    {settings.readingMask && <Check size={14} />}
                  </button>

                  <button 
                    onClick={() => toggle('paragraphFocus')}
                    className={`flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-all border ${
                      settings.paragraphFocus ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-500'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Layout size={14} /> Paragraph Focus
                    </div>
                    {settings.paragraphFocus && <Check size={14} />}
                  </button>

                  <button 
                    onClick={() => toggle('zenMode')}
                    className={`flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-all border ${
                      settings.zenMode ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-500'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <MonitorOff size={14} /> Zen Mode
                    </div>
                    {settings.zenMode && <Check size={14} />}
                  </button>
                </div>

                {/* Screen Overlays */}
                <div className="space-y-2 pt-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1 flex items-center gap-2">
                    <Paintbrush size={12} /> Screen Tints
                  </span>
                  <div className="grid grid-cols-3 gap-1.5">
                    {[
                      { id: 'none', label: 'None' },
                      { id: 'sepia', label: 'Sepia' },
                      { id: 'calm-blue', label: 'Blue' },
                      { id: 'soft-rose', label: 'Rose' },
                      { id: 'low-light', label: 'Low' }
                    ].map(overlay => (
                      <button 
                        key={overlay.id}
                        onClick={() => setOverlay(overlay.id as ScreenOverlayType)}
                        className={`py-2 rounded-lg text-[9px] font-black transition-all border ${
                          settings.screenOverlay === overlay.id 
                          ? 'bg-indigo-600 text-white border-indigo-600' 
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-400'
                        }`}
                      >
                        {overlay.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Voice Control */}
              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 block px-1 flex items-center gap-2">
                  <Mic size={12} /> Voice Commands
                </span>
                <button 
                  onClick={() => toggle('voiceControlEnabled')}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-all border ${
                    settings.voiceControlEnabled 
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' 
                    : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {settings.voiceControlEnabled ? 'Listening Active' : 'Enable Listening'}
                  {settings.voiceControlEnabled ? <Check size={14} /> : <Mic size={14} />}
                </button>
              </div>

              {/* Font & Spacing */}
              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 block px-1 flex items-center gap-2">
                  <Type size={12} /> Typeface & Spacing
                </span>
                
                <div className="flex items-center gap-2 mb-2">
                  <button 
                    onClick={() => toggle('dyslexiaFont')}
                    className={`flex-1 flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-all border ${
                      settings.dyslexiaFont 
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' 
                      : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                    }`}
                  >
                    Dyslexia Friendly
                  </button>
                  <button 
                    onClick={toggleFontType}
                    disabled={!settings.dyslexiaFont}
                    title="Change Dyslexia Font"
                    className={`p-3 rounded-xl border transition-all ${
                      settings.dyslexiaFont 
                      ? 'bg-white dark:bg-slate-800 border-indigo-100 dark:border-indigo-800 text-indigo-600 hover:bg-indigo-50' 
                      : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-300'
                    }`}
                  >
                    <RefreshCw size={14} className={settings.dyslexiaFont ? '' : 'opacity-30'} />
                  </button>
                </div>
                {settings.dyslexiaFont && (
                  <p className="text-[9px] font-black uppercase text-indigo-500 px-1 mb-2 animate-in fade-in slide-in-from-left-2 duration-300">
                    Active: {settings.dyslexiaFontType === 'open' ? 'OpenDyslexic' : 'Lexend'}
                  </p>
                )}

                <div className="space-y-3 px-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">Line Height</span>
                    <span className="text-[10px] text-indigo-600 font-black">{(settings.lineHeight || 1.5).toFixed(1)}x</span>
                  </div>
                  <div className="grid grid-cols-4 gap-1">
                    {[1.2, 1.5, 1.8, 2.2].map(lh => (
                      <button key={lh} onClick={() => setNumeric('lineHeight', lh)} className={`py-1.5 rounded-lg text-[9px] font-black border ${settings.lineHeight === lh ? 'bg-indigo-600 text-white' : 'bg-slate-50 dark:bg-slate-800 text-slate-400'}`}>
                        {lh.toFixed(1)}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Scaling */}
              <div className="space-y-2">
                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 block px-1">Text Scale</span>
                 <div className="grid grid-cols-4 gap-1.5">
                    {[0.8, 1.0, 1.2, 1.4].map(s => (
                      <button 
                        key={s}
                        onClick={() => setNumeric('textScale', s)}
                        className={`py-2 rounded-lg text-[10px] font-black transition-all border ${
                          settings.textScale === s 
                          ? 'bg-indigo-600 text-white border-indigo-600' 
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-400'
                        }`}
                      >
                        {s === 1.0 ? 'STD' : `${(s * 100).toFixed(0)}%`}
                      </button>
                    ))}
                 </div>
              </div>
            </div>
          </div>
        )}

        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`w-16 h-16 rounded-[2rem] flex items-center justify-center transition-all shadow-2xl pointer-events-auto ${
            isOpen ? 'bg-indigo-600 text-white scale-110 -rotate-12' : 'bg-white dark:bg-slate-900 text-indigo-600 border border-slate-100 dark:border-slate-800 hover:scale-110'
          }`}
          title="Accessibility Settings"
        >
          <Eye size={24} />
        </button>
      </div>
    </>
  );
};

export default AccessibilityFab;
