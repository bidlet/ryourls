
import React, { useState, useEffect, useRef } from 'react';
import Layout from './components/Layout';
import PhoneLayout from './components/PhoneLayout';
import FlashcardSession from './components/FlashcardSession';
import SettingsModal from './components/SettingsModal';
import InteractiveText from './components/InteractiveText';
import VoiceSession from './components/VoiceSession';
import FloatingTTS from './components/FloatingTTS';
import AccessibilityFab from './components/AccessibilityFab';
import { Message, Project, Chat, ViewType, FlashcardSet, UserSettings, AIPersonality } from './types';
import { sendMessageToGemini, generateChatTitle } from './services/geminiService';
import { initVoiceControl } from './services/accessibility2';
import SourceCard from './components/SourceCard';
import { initSecurityProtection } from './services/protection';
import { copyToClipboard } from './services/copying';
import { speakText } from './services/ttsService';
import { getOrInitUser } from './services/collaborationService';
import { saveSharedContent, getSharedContent } from './services/storageService';
import { Send, Loader2, BookText, ShieldCheck, Search as SearchIcon, Globe, Zap, AlertCircle, Copy, Edit3, ChevronLeft, ChevronRight, Check, X as CloseIcon, Share2, LinkIcon, ExternalLink, Save, ArrowRight, Mic, Volume2, Clock, Trash2, MessageSquareDashed, Image as ImageIcon, XCircle, Settings2, Hash, Volume1, Play, Info, Heart, GraduationCap, Code, Shield, Share, LayoutList, History, CloudDownload, Box } from 'lucide-react';

const STORAGE_KEYS = {
  PROJECTS: 'scholarsphere_projects',
  CHATS: 'scholarsphere_chats',
  DELETED_CHATS: 'scholarsphere_deleted_chats',
  FLASHCARDS: 'scholarsphere_flashcards',
  SETTINGS: 'scholarsphere_settings',
  SAVED_SHARED: 'scholarsphere_saved_shared',
  VIEW: 'scholarsphere_view'
};

const generateRandomId = () => Math.random().toString(36).substring(2, 10);

const getTimeGreeting = () => {
  const hour = new Date().getHours();
  if (hour === 12) return "Noon";
  if (hour >= 5 && hour < 12) return "Morning";
  if (hour >= 12 && hour < 17) return "Afternoon";
  if (hour >= 17 && hour < 21) return "Evening";
  return "Night";
};

const EXPIRY_OPTIONS = [
  { label: '1 Minute', value: 60 * 1000 },
  { label: '5 Minutes', value: 5 * 60 * 1000 },
  { label: '15 Minutes', value: 15 * 60 * 1000 },
  { label: '1 Hour', value: 60 * 60 * 1000 },
  { label: '24 Hours', value: 24 * 60 * 60 * 1000 },
];

const VOICES = [
  { id: 'Puck', label: 'Ryo (Default)' },
  { id: 'Zephyr', label: 'Brittany' },
  { id: 'Charon', label: 'Gary' },
  { id: 'Kore', label: 'Kore' },
  { id: 'Fenrir', label: 'Mordechai' }
];

const PERSONALITIES: AIPersonality[] = ['Academic', 'Encouraging', 'Concise', 'Socratic'];

const AboutModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 animate-in fade-in duration-300">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden relative flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300 border border-indigo-100 dark:border-indigo-900">
        <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-indigo-50/50 dark:bg-indigo-950/20">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg">
              <GraduationCap size={28} />
            </div>
            <div>
              <h2 className="text-2xl font-black text-slate-800 dark:text-slate-100">About Ryo AI</h2>
              <p className="text-[10px] font-black uppercase tracking-widest text-indigo-500">Version 3.5.0 Secure</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white dark:hover:bg-slate-800 rounded-xl text-slate-400 transition-all border border-transparent hover:border-slate-100 dark:hover:border-slate-700">
            <CloseIcon size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-10 no-scrollbar">
          <section className="space-y-4">
            <div className="flex items-center gap-3 text-indigo-600 font-black uppercase tracking-widest text-xs">
              <Shield size={18} /> Integrity Standard
            </div>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed font-medium">
              Ryo AI uses a high-integrity academic synthesis engine. All research is "grounded" in verified articles, bypassing user-edited sites like Wikipedia or Reddit. Every shared link is compressed and obfuscated to ensure academic privacy.
            </p>
          </section>
        </div>

        <div className="p-8 bg-slate-50 dark:bg-slate-950/50 border-t border-slate-100 dark:border-slate-800 flex flex-col items-center gap-4">
          <a href="https://www.bidlet.app" target="_blank" rel="noopener noreferrer" className="px-6 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] text-indigo-600 hover:bg-indigo-50 transition-all shadow-sm flex items-center gap-2">
            Powered by Bidlet <ExternalLink size={12} />
          </a>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [view, setView] = useState<ViewType>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.VIEW);
    return (saved as ViewType) || 'research';
  });
  
  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PROJECTS);
    return saved ? JSON.parse(saved) : [];
  });
  
  const [chats, setChats] = useState<Chat[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CHATS);
    return saved ? JSON.parse(saved).filter((c: Chat) => !c.deletedAt) : [];
  });

  const [deletedChats, setDeletedChats] = useState<Chat[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DELETED_CHATS);
    return saved ? JSON.parse(saved) : [];
  });

  const [savedSharedChats, setSavedSharedChats] = useState<{name: string, data: string}[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SAVED_SHARED);
    return saved ? JSON.parse(saved) : [];
  });
  
  const [savedFlashcards, setSavedFlashcards] = useState<FlashcardSet[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.FLASHCARDS);
    return saved ? JSON.parse(saved) : [];
  });
  
  const [settings, setSettings] = useState<UserSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    const defaults: UserSettings = {
      personality: 'Academic',
      customPersonality: '',
      blacklistedDomains: [],
      strictFilterEnabled: true,
      theme: 'light',
      accessibility: {
        dyslexiaFont: false,
        dyslexiaFontType: 'open',
        textScale: 1.0,
        subtleColors: false,
        lineHeight: 1.5,
        letterSpacing: 0,
        highlightLinks: false,
        largeCursor: false,
        voiceControlEnabled: false,
        readingMask: false,
        paragraphFocus: false,
        zenMode: false,
        screenOverlay: 'none',
        pomodoroEnabled: false
      }
    };
    const loaded = saved ? { ...defaults, ...JSON.parse(saved) } : defaults;
    return getOrInitUser(loaded);
  });

  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [sharedChat, setSharedChat] = useState<Chat | null>(null);
  const [sharedProject, setSharedProject] = useState<Project | null>(null);
  const [sharedChats, setSharedChats] = useState<Chat[]>([]);
  const [currentSharedSlug, setCurrentSharedSlug] = useState<string | null>(null);
  const [isFetchingShared, setIsFetchingShared] = useState(false);

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [isProjectSettingsOpen, setIsProjectSettingsOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [privacyWarning, setPrivacyWarning] = useState<string | null>(null);
  const [showShareSuccess, setShowShareSuccess] = useState(false);
  const [showPublishSuccess, setShowPublishSuccess] = useState(false);
  const [showSlugSaveSuccess, setShowSlugSaveSuccess] = useState(false);
  const [previewingVoiceId, setPreviewingVoiceId] = useState<string | null>(null);
  
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  const [isTempDropdownOpen, setIsTempDropdownOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<{ data: string; mimeType: string } | null>(null);
  
  const [pendingProjectName, setPendingProjectName] = useState<string | null>(null);
  const [tempSlug, setTempSlug] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const voiceControlRef = useRef<any>(null);
  const isVoiceActiveRef = useRef(false);

  const activeProject = sharedProject || projects.find(p => p.id === activeProjectId);

  useEffect(() => {
    if (activeProject) {
      setTempSlug(activeProject.customSlug || activeProject.id);
    }
  }, [activeProjectId, activeProject?.customSlug, sharedProject]);

  const handleCreateProjectWithName = (name: string) => {
    if (projects.some(p => p.name === name)) {
      setPendingProjectName(null);
      return;
    }
    const projectId = generateRandomId();
    const newProject: Project = { 
      id: projectId, 
      name, 
      chatIds: [], 
      createdAt: Date.now(), 
      personality: 'Academic',
      ownerId: settings.userId,
      defaultVoiceId: 'Puck'
    };
    setProjects(prev => [newProject, ...prev]);
    window.location.hash = `#/p/${projectId}`;
    setPendingProjectName(null);
  };

  /**
   * Finalizes project creation from the modal view.
   */
  const handleCreateProjectFinal = () => {
    if (!newProjectName.trim()) return;
    handleCreateProjectWithName(newProjectName);
    setNewProjectName('');
    setIsProjectModalOpen(false);
  };

  const handleDeleteProject = (projectId: string) => {
    setProjects(prev => prev.filter(p => p.id !== projectId));
    setChats(prev => prev.filter(c => c.projectId !== projectId));
    if (activeProjectId === projectId) {
      setActiveProjectId(null);
      setView('research');
      window.location.hash = '#/research';
    }
  };

  const handleUpdateProject = (projectId: string, updates: Partial<Project>) => {
    setProjects(prev => prev.map(p => p.id === projectId ? { ...p, ...updates } : p));
  };

  const handleSaveProjectUrl = () => {
    if (!activeProject || sharedProject) return;
    const cleanSlug = tempSlug.toLowerCase().replace(/[^a-z0-9-]/g, '');
    if (!cleanSlug) return;
    handleUpdateProject(activeProject.id, { customSlug: cleanSlug });
    window.location.href = `${window.location.origin}${window.location.pathname}#/p/${cleanSlug}`;
    setShowSlugSaveSuccess(true);
    setTimeout(() => setShowSlugSaveSuccess(false), 2000);
  };

  const handlePublishProject = async () => {
    if (!activeProject || sharedProject) return;
    setIsLoading(true);
    try {
      const projectChats = chats.filter(c => c.projectId === activeProject.id);
      const data = {
        project: activeProject,
        chats: projectChats.map(c => ({
          ...c,
          messages: c.messages.map(m => ({
            role: m.role, text: m.text, sources: m.sources, timestamp: m.timestamp
          }))
        }))
      };
      
      const slug = await saveSharedContent('project', data);
      const url = `${window.location.origin}/#/a/${slug}`;
      await copyToClipboard(url);
      setShowPublishSuccess(true);
      setTimeout(() => setShowPublishSuccess(false), 3000);
    } catch (e) {
      alert("Failed to secure archive.");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePreviewVoice = async (voiceId: string) => {
    if (previewingVoiceId) return;
    setPreviewingVoiceId(voiceId);
    try {
      await speakText(`Academic synthesis voice ready.`, voiceId);
    } catch (e) {} finally {
      setPreviewingVoiceId(null);
    }
  };

  useEffect(() => {
    const { theme, accessibility } = settings;
    if (theme === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    
    if (accessibility.largeCursor) document.body.classList.add('large-cursor');
    else document.body.classList.remove('large-cursor');
    
    document.documentElement.style.setProperty('--ryo-line-height', accessibility.lineHeight.toString());
    document.documentElement.style.setProperty('--ryo-letter-spacing', `${accessibility.letterSpacing}rem`);
    document.documentElement.style.setProperty('--ryo-text-scale', accessibility.textScale.toString());
  }, [settings]);

  useEffect(() => {
    const handleHashChange = async () => {
      const hash = window.location.hash;
      
      if (!hash.startsWith('#/a/')) {
        setIsFetchingShared(false);
      }

      if (!hash.startsWith('#/a/') && !hash.startsWith('#/chat/') && !hash.startsWith('#/p/')) {
        setSharedChat(null);
        setSharedProject(null);
        setSharedChats([]);
        setCurrentSharedSlug(null);
      }

      if (hash.startsWith('#/p/')) {
        const slug = hash.replace('#/p/', '').split('?')[0];
        const project = projects.find(p => p.id === slug || p.customSlug === slug);
        if (project) {
          setActiveProjectId(project.id);
          setActiveChatId(null);
          setView('project-home');
        }
      } else if (hash.startsWith('#/chat/')) {
        const id = hash.replace('#/chat/', '').split('?')[0];
        const localChat = chats.find(c => c.id === id);
        if (localChat) {
          setActiveChatId(id);
          setActiveProjectId(localChat.projectId);
          setView(current => (current === 'brief' || current === 'site-finder' || current === 'voice') ? current : 'research');
        }
      } else if (hash.startsWith('#/a/')) {
        const slug = hash.replace('#/a/', '').split('?')[0];
        setIsFetchingShared(true);
        // Instant simulated fetch from compressed state
        const content = await getSharedContent(slug);
        if (content) {
          if (content.type === 'chat') {
            setSharedChat({ ...content.data, id: 'shared-' + generateRandomId() });
            setCurrentSharedSlug(slug);
            setActiveChatId(null);
            setView('research');
          } else if (content.type === 'project') {
            const { project, chats: pChats } = content.data;
            setSharedProject(project);
            setSharedChats(pChats.map((c: any) => ({ ...c, isSharedProject: true })));
            setCurrentSharedSlug(slug);
            
            const queryParams = new URLSearchParams(hash.split('?')[1]);
            const chatIdx = queryParams.get('chatIdx');
            if (chatIdx !== null) {
              const idx = parseInt(chatIdx);
              if (!isNaN(idx) && pChats[idx]) {
                setSharedChat({ ...pChats[idx], isSharedProject: true });
                setActiveChatId(null);
                setView('research');
              }
            } else {
              setActiveChatId(null);
              setView('project-home');
            }
          }
        } else {
          alert("Archive retrieval failed. Link is invalid or corrupt.");
          window.location.hash = '#/research';
        }
        setIsFetchingShared(false);
      } else {
        const routeMap: Record<string, ViewType> = {
          '#/flashcards': 'flashcards',
          '#/site-finder': 'site-finder',
          '#/brief': 'brief',
          '#/voice': 'voice',
          '#/research': 'research',
          '': 'research',
          '#/': 'research'
        };
        const viewMatch = routeMap[hash] || 'research';
        setView(viewMatch);
        setActiveChatId(null);
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [chats, projects]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CHATS, JSON.stringify(chats));
  }, [chats]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SAVED_SHARED, JSON.stringify(savedSharedChats));
  }, [savedSharedChats]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    localStorage.setItem(STORAGE_KEYS.FLASHCARDS, JSON.stringify(savedFlashcards));
    localStorage.setItem(STORAGE_KEYS.DELETED_CHATS, JSON.stringify(deletedChats));
  }, [settings, savedFlashcards, deletedChats]);

  useEffect(() => {
    initSecurityProtection();
  }, []);

  const activeChat = sharedChat || chats.find(c => c.id === activeChatId);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [activeChat?.messages, isLoading, view]);

  const toggleGuard = () => {
    setSettings(prev => ({ ...prev, strictFilterEnabled: !prev.strictFilterEnabled }));
  };

  const handleNewChat = (projectId: string, isTemporary = false, duration?: number) => {
    const chatId = generateRandomId();
    const newChat: Chat = { 
      id: chatId, 
      projectId, 
      name: isTemporary ? "Temporary Session" : "New Research Session", 
      messages: [], 
      updatedAt: Date.now(),
      isTemporary,
      expiresAt: isTemporary && duration ? Date.now() + duration : undefined
    };
    setChats(prev => [newChat, ...prev]);
    setProjects(prev => prev.map(p => p.id === projectId ? { ...p, chatIds: [...p.chatIds, chatId] } : p));
    window.location.hash = `#/chat/${chatId}`;
    setIsTempDropdownOpen(false);
  };

  const handleRenameChat = (id: string, name: string) => {
    setChats(prev => prev.map(c => c.id === id ? { ...c, name, updatedAt: Date.now() } : c));
  };

  const handleDeleteChat = (id: string) => {
    const chatToDelete = chats.find(c => c.id === id);
    if (!chatToDelete) return;
    setChats(prev => prev.filter(c => c.id !== id));
    setDeletedChats(prev => [{ ...chatToDelete, deletedAt: Date.now() }, ...prev]);
    if (activeChatId === id) window.location.hash = '';
  };

  const handleRestoreChat = (id: string) => {
    const target = deletedChats.find(c => c.id === id);
    if (!target) return;
    const { deletedAt, ...restored } = target;
    setDeletedChats(prev => prev.filter(c => c.id !== id));
    setChats(prev => [...prev, restored]);
  };

  const handleShareChat = async () => {
    if (!activeChat) return;
    setIsLoading(true);
    try {
      const data = {
        name: activeChat.name,
        projectId: activeChat.projectId,
        messages: activeChat.messages.map(m => ({
          role: m.role, text: m.text, sources: m.sources, timestamp: m.timestamp
        }))
      };
      
      const slug = await saveSharedContent('chat', data);
      const url = `${window.location.origin}/#/a/${slug}`;
      await copyToClipboard(url);
      setShowShareSuccess(true);
      setTimeout(() => setShowShareSuccess(false), 3000);
    } catch (e) {
      alert("Failed to share snapshot.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveSharedChat = () => {
    if (!sharedChat || !currentSharedSlug) return;
    if (!savedSharedChats.some(s => s.data === currentSharedSlug)) {
      setSavedSharedChats(prev => [...prev, { name: sharedChat.name, data: currentSharedSlug }]);
    }
  };

  const handleDeleteSavedShared = (data: string) => {
    setSavedSharedChats(prev => prev.filter(s => s.data !== data));
  };

  const handleSwitchVersion = (chatId: string, msgId: string, offset: number) => {
    setChats(prev => prev.map(c => {
      if (c.id !== chatId) return c;
      return {
        ...c,
        messages: c.messages.map(m => {
          if (m.id !== msgId || !m.versions) return m;
          const curr = m.activeVersionIndex || 0;
          const next = Math.max(0, Math.min(m.versions.length - 1, curr + offset));
          const ver = m.versions[next];
          return { ...m, activeVersionIndex: next, text: ver.text, sources: ver.sources, timestamp: ver.timestamp };
        })
      };
    }));
  };

  /**
   * Handles file selection and updates the local image state.
   */
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        const data = base64.split(',')[1];
        setSelectedImage({ data, mimeType: file.type });
      };
      reader.readAsDataURL(file);
    }
  };

  /**
   * Toggles browser-based speech recognition for text input.
   */
  const handleVoiceToText = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in your browser.");
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const rec = new SpeechRecognition();
    rec.continuous = false;
    rec.interimResults = false;
    rec.lang = 'en-US';

    rec.onstart = () => setIsListening(true);
    rec.onend = () => setIsListening(false);
    rec.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputValue(prev => prev + (prev ? " " : "") + transcript);
    };

    rec.start();
    recognitionRef.current = rec;
  };

  const handleSendMessage = async (e?: React.FormEvent, isRegen = false, targetId?: string) => {
    e?.preventDefault();
    if (sharedChat) return;
    const txt = isRegen ? editValue : inputValue;
    if ((!txt.trim() && !selectedImage) || isLoading) return;

    if (!activeProjectId) { setIsProjectModalOpen(true); return; }
    let cId = activeChatId;
    if (!cId) {
      cId = generateRandomId();
      const nC: Chat = { id: cId, projectId: activeProjectId, name: "New Research Session", messages: [], updatedAt: Date.now() };
      setChats(prev => [nC, ...prev]);
      setProjects(prev => prev.map(p => p.id === activeProjectId ? { ...p, chatIds: [...p.chatIds, cId!] } : p));
      window.location.hash = `#/chat/${cId}`;
    }

    const currentChat = chats.find(c => c.id === cId);
    if (!currentChat) return;

    setIsLoading(true);
    const modelMsgId = generateRandomId();
    const curImg = selectedImage;
    const imgUrl = curImg ? `data:${curImg.mimeType};base64,${curImg.data}` : undefined;

    let nextMsgs: Message[] = [];
    let userMsg: Message | null = null;

    if (isRegen && targetId) {
      const uIdx = currentChat.messages.findIndex(m => m.id === targetId);
      nextMsgs = currentChat.messages.map((m, idx) => {
        if (m.id === targetId) return { ...m, text: txt, updatedAt: Date.now() };
        if (idx === uIdx + 1) return { ...m, text: '', sources: [] };
        return m;
      });
      setEditingMessageId(null); setEditValue('');
    } else {
      userMsg = { id: generateRandomId(), role: 'user', text: txt, imageUrl: imgUrl, timestamp: Date.now(), senderId: settings.userId, senderColor: settings.userColor, senderName: settings.userName };
      const mP: Message = { id: modelMsgId, role: 'model', text: '', timestamp: Date.now() };
      nextMsgs = [...currentChat.messages, userMsg, mP];
      setInputValue(''); setSelectedImage(null);
    }

    setChats(p => p.map(c => c.id === cId ? { ...c, messages: nextMsgs, updatedAt: Date.now() } : c));

    try {
      const count = isRegen ? currentChat.messages.findIndex(m => m.id === targetId) + 1 : nextMsgs.length + 1;
      const history = nextMsgs.slice(0, count).filter(m => m.text).map(m => ({ role: m.role, parts: [{ text: m.text }] }));
      const lastU = nextMsgs.slice(0, count).reverse().find(m => m.role === 'user')?.text || txt;

      const res = await sendMessageToGemini(lastU, history.slice(0, -1), settings, view === 'site-finder', view === 'brief', (stream) => {
        setChats(p => p.map(c => {
          if (c.id !== cId) return c;
          return {
            ...c,
            messages: c.messages.map(m => {
              if (isRegen) {
                const uIdx = c.messages.findIndex(msg => msg.id === targetId);
                if (m.id === c.messages[uIdx+1]?.id) return { ...m, text: stream };
              } else if (m.id === modelMsgId) return { ...m, text: stream };
              return m;
            })
          };
        }));
      }, curImg || undefined);

      setChats(p => p.map(c => {
        if (c.id !== cId) return c;
        const newM = [...c.messages];
        const uI = newM.findIndex(m => m.id === (targetId || userMsg?.id));
        const mI = uI + 1;
        const target = newM[mI];
        if (target) {
          if (isRegen) {
            const newVer = { text: res.text, sources: res.sources, timestamp: Date.now() };
            const baseVers = target.versions || [{ text: target.text, sources: target.sources, timestamp: target.timestamp }];
            const finalVers = [...baseVers, newVer];
            newM[mI] = { ...target, text: res.text, sources: res.sources, timestamp: Date.now(), versions: finalVers, activeVersionIndex: finalVers.length - 1 };
          } else {
            newM[mI] = { ...target, text: res.text, sources: res.sources, timestamp: Date.now() };
          }
        }
        return { ...c, messages: newM, updatedAt: Date.now() };
      }));

      if (!isRegen && nextMsgs.length === 2 && !currentChat.isTemporary) {
        generateChatTitle(txt, res.text).then(t => handleRenameChat(cId!, t));
      }
    } catch (e: any) {
      const errM: Message = { id: generateRandomId(), role: 'model', text: `[Error] ${e.message === 'QUOTA_EXHAUSTED' ? 'Quota exceeded.' : 'Failed.'}`, timestamp: Date.now() };
      setChats(p => p.map(c => c.id === cId ? { ...c, messages: [...c.messages.filter(m => m.id !== modelMsgId), errM] } : c));
    } finally { setIsLoading(false); }
  };

  const [timeLeft, setTimeLeft] = useState("");
  useEffect(() => {
    if (!activeChat?.isTemporary || !activeChat?.expiresAt) { setTimeLeft(""); return; }
    const t = setInterval(() => {
      const rem = activeChat.expiresAt! - Date.now();
      if (rem <= 0) { setTimeLeft("Expired"); clearInterval(t); return; }
      const m = Math.floor(rem / 60000), s = Math.floor((rem % 60000) / 1000);
      setTimeLeft(`${m}:${s.toString().padStart(2, '0')}`);
    }, 1000);
    return () => clearInterval(t);
  }, [activeChat]);

  return (
    <div className={`flex h-screen w-full flex-col overflow-hidden ${settings.accessibility.subtleColors ? 'subtle-colors' : ''}`}>
      {settings.accessibility.readingMask && <div className="reading-mask" />}
      {settings.accessibility.screenOverlay !== 'none' && <div className={`overlay-layer overlay-${settings.accessibility.screenOverlay}`} />}
      
      {isFetchingShared && (
        <div className="fixed inset-0 z-[500] bg-slate-900/60 backdrop-blur-xl flex flex-col items-center justify-center text-white space-y-6 animate-in fade-in duration-300">
           <div className="relative">
             <div className="w-24 h-24 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin" />
             <Box size={40} className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-indigo-400 animate-pulse" />
           </div>
           <div className="text-center space-y-2">
             <h3 className="text-2xl font-black uppercase tracking-[0.2em]">Unpacking Archive</h3>
             <p className="text-sm font-medium text-white/40 uppercase tracking-widest">Decoding Secure Portable State...</p>
           </div>
        </div>
      )}

      <Layout
        projects={projects} chats={chats} activeProjectId={activeProjectId} activeChatId={activeChatId}
        savedSharedChats={savedSharedChats}
        onNewProject={() => setIsProjectModalOpen(true)} onNewChat={handleNewChat}
        onSelectProject={(id) => { const p = projects.find(x => x.id === id); if (p) window.location.hash = `#/p/${p.customSlug || p.id}`; }}
        onSelectChat={(id) => window.location.hash = `#/chat/${id}`}
        onSelectShared={(slug) => window.location.hash = `#/a/${slug}`}
        onDeleteSavedShared={handleDeleteSavedShared}
        onRenameProject={(id, name) => handleUpdateProject(id, { name })}
        onDeleteProject={handleDeleteProject}
        onRenameChat={handleRenameChat} onDeleteChat={handleDeleteChat}
        onChangeProjectPersonality={(id, personality) => handleUpdateProject(id, { personality })}
        view={view} onSetView={(v) => { setView(v); window.location.hash = `#/${v}`; }} onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenAbout={() => setIsAboutOpen(true)}
        isSearchModalOpen={isSearchModalOpen} setIsSearchModalOpen={setIsSearchModalOpen}
      >
        {isAboutOpen && <AboutModal onClose={() => setIsAboutOpen(false)} />}
        {isSettingsOpen && <SettingsModal settings={settings} onSave={setSettings} onClose={() => setIsSettingsOpen(false)} deletedChats={deletedChats} onRestoreChat={handleRestoreChat} onClearVault={() => setDeletedChats([])} />}
        {isProjectModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
            <div className="bg-white dark:bg-slate-900 w-full max-md rounded-3xl shadow-2xl p-6 space-y-6">
              <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">New Project</h3>
              <input autoFocus className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 dark:text-slate-100 dark:border-slate-700 border rounded-xl outline-none" placeholder="Project Name..." value={newProjectName} onChange={e => setNewProjectName(e.target.value)} />
              <div className="flex gap-3"><button onClick={() => setIsProjectModalOpen(false)} className="flex-1 py-3 text-slate-500 font-bold">Cancel</button><button onClick={handleCreateProjectFinal} disabled={!newProjectName.trim()} className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-xl shadow-lg">Create</button></div>
            </div>
          </div>
        )}
        {view === 'project-home' && activeProject ? (
          <div className="flex-1 flex flex-col items-center p-8 bg-slate-50/50 dark:bg-slate-950/50 overflow-y-auto relative no-scrollbar">
            <div className="absolute top-8 right-8 flex items-center gap-3">
              {!sharedProject && (
                <div className="relative group">
                  <button onClick={handlePublishProject} className="p-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl text-slate-400 hover:text-indigo-600 shadow-sm transition-all flex items-center gap-2 font-bold text-xs uppercase tracking-widest px-6">{isLoading ? <Loader2 className="animate-spin" size={18}/> : <Share size={18}/>} {showPublishSuccess ? 'Archive Ready!' : 'Secure Share'}</button>
                  {showPublishSuccess && (<div className="absolute top-full mt-2 right-0 bg-slate-800 text-white px-3 py-1.5 rounded-xl text-[9px] font-black uppercase whitespace-nowrap z-50 animate-in fade-in">Short Slug Copied</div>)}
                </div>
              )}
              {!sharedProject && (
                <button onClick={() => setIsProjectSettingsOpen(true)} className="p-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl text-slate-400 hover:text-indigo-600 shadow-sm transition-all group"><Settings2 size={24} className="group-hover:rotate-45 transition-transform duration-500" /></button>
              )}
            </div>
            <div className="max-w-4xl w-full space-y-12 text-center animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
              <div className="space-y-4 pt-10">
                <h1 className="text-4xl md:text-5xl font-black text-slate-800 dark:text-slate-100">{sharedProject ? 'Secure Archive' : `Good ${getTimeGreeting()}!`}</h1>
                <p className="text-xl text-slate-500 dark:text-slate-400 font-medium">{sharedProject ? 'Restored Project:' : 'Select a research hub in'} <span className="text-indigo-600 font-bold">{activeProject.name}</span></p>
              </div>
              
              {!sharedProject ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                    <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
                       <div className="flex items-center gap-3 text-indigo-600 font-black uppercase tracking-widest text-[10px]"><LinkIcon size={16} /> Custom Project Slug</div>
                       <div className="flex gap-2"><div className="relative flex-1"><div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 font-mono text-sm">/p/</div><input type="text" value={tempSlug} onChange={(e) => setTempSlug(e.target.value)} placeholder={activeProject.id} className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl dark:text-white outline-none focus:ring-2 focus:ring-indigo-500/20 font-mono text-sm" /></div><button onClick={handleSaveProjectUrl} disabled={tempSlug === (activeProject.customSlug || activeProject.id)} className={`px-4 py-3 rounded-xl font-bold text-xs uppercase transition-all ${tempSlug === (activeProject.customSlug || activeProject.id) ? 'bg-slate-100 dark:bg-slate-800 text-slate-300' : 'bg-indigo-600 text-white shadow-lg'}`}>{showSlugSaveSuccess ? <Check size={18}/> : 'Save'}</button></div>
                    </div>
                    <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
                      <div className="flex items-center gap-3 text-indigo-600 font-black uppercase tracking-widest text-[10px]"><Volume2 size={16} /> Synthesis Voice</div>
                      <div className="grid grid-cols-1 gap-2">
                        {VOICES.map(v => {
                          const isSelected = (activeProject.defaultVoiceId || 'Puck') === v.id;
                          return (
                            <button key={v.id} onClick={() => handleUpdateProject(activeProject.id, { defaultVoiceId: v.id })} className={`text-left px-4 py-2.5 rounded-xl text-xs font-bold transition-all border ${isSelected ? 'bg-indigo-600 text-white border-indigo-600 shadow-md' : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-500 hover:bg-slate-100'}`}>{v.label}</button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">{[{ id: 'research', title: 'Research Lab', icon: <SearchIcon size={32}/>, color: 'indigo', desc: 'Deep academic searches with citations.' }, { id: 'brief', title: 'Brief Answers', icon: <Zap size={32}/>, color: 'orange', desc: 'Ultra-concise factoids and definitions.' }, { id: 'site-finder', title: 'Find Sites', icon: <Globe size={32}/>, color: 'emerald', desc: 'Direct access to institutional resources.' }].map((box) => (<button key={box.id} onClick={() => { setView(box.id as ViewType); window.location.hash = `#/${box.id}`; }} className="group relative flex flex-col items-center p-8 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[2.5rem] shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300 text-center"><div className={`p-4 bg-${box.color}-50 dark:bg-${box.color}-950/30 text-${box.color}-600 rounded-2xl mb-6 group-hover:scale-110 transition-transform`}>{box.icon}</div><h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2">{box.title}</h3><p className="text-sm text-slate-400 font-medium leading-relaxed">{box.desc}</p></button>))}</div>
                </>
              ) : (
                <div className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-100 dark:border-slate-800 shadow-xl max-w-2xl mx-auto space-y-8 animate-in slide-in-from-top-4">
                  <div className="flex items-center justify-between"><div className="flex items-center gap-3 text-indigo-600 font-black uppercase tracking-[0.2em] text-xs"><LayoutList size={20} /> Archive History</div><span className="text-[10px] bg-emerald-50 dark:bg-emerald-950 text-emerald-600 px-3 py-1 rounded-full font-black uppercase">Obfuscated Snapshot</span></div>
                  <div className="space-y-4">
                    {sharedChats.map((chat, idx) => (
                      <button key={idx} onClick={() => { window.location.hash = `#/a/${currentSharedSlug}?chatIdx=${idx}`; }} className="w-full flex items-center justify-between p-5 bg-slate-50 dark:bg-slate-800 border border-transparent hover:border-indigo-200 rounded-2xl group transition-all">
                        <div className="flex items-center gap-4 text-left"><div className="p-3 bg-white dark:bg-slate-900 rounded-xl text-indigo-600"><MessageSquareDashed size={20} /></div><div><h4 className="font-bold text-slate-800 dark:text-slate-100">{chat.name}</h4><div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400 uppercase tracking-widest font-bold italic">Portable Research Block</div></div></div>
                        <ArrowRight size={20} className="text-slate-300 group-hover:text-indigo-500" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : view === 'voice' ? <VoiceSession settings={settings} activeProject={activeProject} onUpdateProjectVoice={(id, v) => handleUpdateProject(id, { defaultVoiceId: v })} /> : view === 'research' || view === 'site-finder' || view === 'brief' ? (
          <>
            <header className={`h-16 border-b border-slate-200 dark:border-slate-800 glass sticky top-0 z-10 flex items-center justify-between px-6 ${sharedChat ? 'bg-indigo-50/50 dark:bg-indigo-950/20' : ''}`}><div className="flex items-center gap-3 truncate">{sharedChat ? <ShieldCheck className="text-emerald-600" size={20} /> : <>{view === 'research' && <SearchIcon className="text-indigo-600" size={20} />}{view === 'site-finder' && <Globe className="text-emerald-600" size={20} />}{view === 'brief' && <Zap className="text-orange-500" size={20} />}</>}<div className="flex flex-col truncate"><div className="flex items-center gap-3"><h1 className="font-semibold text-slate-700 dark:text-slate-100 truncate leading-tight flex items-center gap-2">{sharedChat ? activeChat?.name : (activeChat ? activeChat.name : 'Research Lab')}</h1>{!sharedChat && activeChat && activeChat.messages.length > 0 && !activeChat.isTemporary && (
              <div className="flex items-center gap-2 shrink-0">
                <div className="relative group shrink-0">
                  <button onClick={handleShareChat} className="p-1.5 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 border border-indigo-100 rounded-lg hover:bg-indigo-600 hover:text-white transition-all shadow-sm flex items-center gap-2 px-3" title="Secure Share">
                    {isLoading ? <Loader2 className="animate-spin" size={14}/> : <Share2 size={14} />}<span className="text-[10px] font-black uppercase hidden sm:inline">Secure Link</span>
                  </button>
                  {showShareSuccess && (<div className="absolute top-full mt-2 left-0 bg-slate-800 text-white px-3 py-1.5 rounded-xl text-[9px] font-black uppercase whitespace-nowrap z-50 animate-in fade-in">Link Copied</div>)}
                </div>
              </div>
            )}</div><span className="text-[10px] font-bold uppercase tracking-widest text-indigo-500">{sharedChat ? 'Secure Snapshot View' : (activeProject ? activeProject.personality : 'Academic')} Mode</span></div></div>{!sharedChat ? (<button onClick={toggleGuard} className={`flex items-center gap-2 px-4 py-2 rounded-full border text-[11px] font-bold uppercase transition-all shadow-sm ${settings.strictFilterEnabled ? 'bg-emerald-600 text-white border-emerald-500 shadow-emerald-200' : 'bg-white dark:bg-slate-900 text-amber-600 border-amber-200 dark:border-amber-900/50'}`}>{settings.strictFilterEnabled ? <ShieldCheck size={16} /> : <AlertCircle size={16} />}{settings.strictFilterEnabled ? 'Integrity Active' : 'Integrity Off'}</button>) : (<div className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-full text-[11px] font-bold uppercase"><ShieldCheck size={16} /> Integrity Verified</div>)}</header>
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8 bg-slate-50/50 dark:bg-slate-950 relative">{!activeChat || activeChat.messages.length === 0 ? (<div className="h-full flex flex-col items-center justify-center text-center max-w-2xl mx-auto space-y-6 px-4"><div className="p-5 bg-white dark:bg-slate-900 border border-slate-100 rounded-3xl shadow-sm text-indigo-600"><BookText size={48} /></div><h2 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Academic Research Hub</h2><p className="text-slate-500 dark:text-slate-400">Verified academic research with zero wiki-based content.</p><button onClick={() => activeProjectId ? handleNewChat(activeProjectId) : setIsProjectModalOpen(true)} className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg">New Session</button></div>) : (<div className="max-w-5xl mx-auto w-full space-y-10 pb-12">{activeChat.messages.map((m) => { const isU = m.role === 'user'; const isE = editingMessageId === m.id; return (<div key={m.id} className={`message-container flex gap-4 ${isU ? 'justify-end' : 'justify-start'}`}><div className={`flex flex-col ${isU ? 'items-end' : 'items-start'} ${isU ? 'max-w-[85%]' : 'max-w-[85%] md:max-w-2xl'}`}><div className={`group relative px-6 py-4 rounded-3xl leading-relaxed shadow-sm ${isU ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-tl-none'}`}>{isE ? (<div className="space-y-3 min-w-[200px]"><textarea autoFocus className="w-full bg-indigo-700/50 text-white border-none rounded-xl p-2 outline-none resize-none overflow-hidden min-h-[60px]" value={editValue} onChange={e => setEditValue(e.target.value)} /><div className="flex justify-end gap-2"><button onClick={() => setEditingMessageId(null)} className="p-1.5 hover:bg-white/10 rounded-lg text-white/70 transition-colors"><CloseIcon size={16}/></button><button onClick={() => handleSendMessage(undefined, true, m.id)} className="p-1.5 bg-white text-indigo-600 rounded-lg font-bold shadow-sm flex items-center gap-1"><Check size={16}/> Save</button></div></div>) : (<div className="space-y-4">{m.imageUrl && (<div className="max-w-xs overflow-hidden rounded-2xl border border-indigo-100 shadow-sm"><img src={m.imageUrl} alt="Uploaded" className="w-full h-auto" /></div>)}<InteractiveText text={m.text} /></div>)}<div className={`absolute top-0 flex gap-1 items-center transition-all opacity-0 group-hover:opacity-100 ${isU ? 'right-full mr-2' : 'left-full ml-2'}`}>{isU && (<><button onClick={() => copyToClipboard(m.text)} className="p-1.5 bg-white dark:bg-slate-800 border rounded-xl text-slate-400 hover:text-indigo-600 shadow-sm transition-all" title="Copy"><Copy size={14} /></button>{!sharedChat && <button onClick={() => { setEditingMessageId(m.id); setEditValue(m.text); }} className="p-1.5 bg-white dark:bg-slate-800 border rounded-xl text-slate-400 hover:text-indigo-600 shadow-sm transition-all" title="Edit"><Edit3 size={14} /></button>}</>)}</div></div>{!isU && m.versions && m.versions.length > 1 && !sharedChat && (<div className="flex items-center gap-2 mt-2 px-2 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest"><button disabled={(m.activeVersionIndex || 0) === 0} onClick={() => handleSwitchVersion(activeChatId!, m.id, -1)} className="p-1 hover:text-indigo-600 disabled:opacity-30"><ChevronLeft size={14} /></button><span>{(m.activeVersionIndex || 0) + 1} / {m.versions.length}</span><button disabled={(m.activeVersionIndex || 0) === m.versions.length - 1} onClick={() => handleSwitchVersion(activeChatId!, m.id, 1)} className="p-1 hover:text-indigo-600 disabled:opacity-30"><ChevronRight size={14} /></button></div>)}{!isU && m.sources && m.sources.length > 0 && (<div className="w-full mt-3"><SourceCard sources={m.sources} /></div>)}<span className="text-[10px] uppercase font-bold text-slate-400 dark:text-slate-600 mt-2 tracking-widest">{isU ? 'You' : 'Ryo AI'}</span></div></div>); })} {isLoading && (<div className="flex justify-start"><div className="px-6 py-4 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-3xl flex items-center gap-3"><Loader2 className="animate-spin text-indigo-600" size={16} /><span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Searching...</span></div></div>)}</div>)}</div>
            <div className="hidden md:block p-4 md:p-6 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">{sharedChat ? (<div className="max-w-4xl mx-auto flex flex-col items-center gap-3"><div className="flex items-center gap-3"><button onClick={() => window.location.hash = ''} className="px-6 py-2.5 bg-slate-800 text-white rounded-xl font-bold shadow-lg flex items-center gap-2 hover:bg-slate-900 transition-all"><ExternalLink size={16} /> Start Your Own Research</button>{!activeChat?.isSharedProject && <button onClick={handleSaveSharedChat} disabled={savedSharedChats.some(s => s.data === currentSharedSlug)} className={`px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all border ${savedSharedChats.some(s => s.data === currentSharedSlug) ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-white dark:bg-slate-900 text-indigo-600 border-indigo-100 hover:bg-indigo-50'}`}>{savedSharedChats.some(s => s.data === currentSharedSlug) ? 'In Your Archive' : 'Save Reference'}</button>}</div></div>) : (<div className="max-w-4xl mx-auto relative"><form onSubmit={handleSendMessage} className="relative flex items-center"><input type="text" value={inputValue} onChange={e => setInputValue(e.target.value)} placeholder={isListening ? "Listening..." : "Ask an academic question..."} className={`w-full pl-6 pr-56 py-4 border rounded-2xl dark:text-slate-100 focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all ${isListening ? 'bg-indigo-50 border-indigo-300' : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700'}`} /><div className="absolute right-2 flex items-center gap-1.5"><input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" /><button type="button" onClick={() => fileInputRef.current?.click()} className="p-2.5 bg-white dark:bg-slate-900 text-slate-400 hover:text-indigo-600 border border-slate-100 rounded-xl transition-all"><ImageIcon size={18} /></button><button type="button" onClick={() => setIsTempDropdownOpen(!isTempDropdownOpen)} className={`p-2.5 rounded-xl transition-all ${isTempDropdownOpen ? 'bg-indigo-600 text-white shadow-lg' : 'bg-white dark:bg-slate-900 text-slate-400 hover:text-indigo-600 border border-slate-100'}`}><MessageSquareDashed size={18} /></button><button type="button" onClick={handleVoiceToText} className={`p-2.5 rounded-xl transition-all ${isListening ? 'bg-indigo-600 text-white animate-pulse' : 'bg-white dark:bg-slate-900 text-slate-400 hover:text-indigo-600 border border-slate-100'}`}><Mic size={18} /></button><button disabled={isLoading || (!inputValue.trim() && !selectedImage)} type="submit" className={`p-2.5 rounded-xl transition-all ${(inputValue.trim() || selectedImage) && !isLoading ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-200 dark:bg-slate-800 text-slate-400'}`}><Send size={18} /></button></div></form></div>)}</div>
          </>
        ) : (<div className="flex-1 h-full min-h-0 pb-24 md:pb-0 overflow-y-auto"><FlashcardSession settings={settings} savedSets={savedFlashcards} onSaveSet={(s) => setSavedFlashcards(pv => [s, ...pv])} onDeleteSet={id => setSavedFlashcards(pv => pv.filter(x => x.id !== id))} /></div>)}
      </Layout>
      <AccessibilityFab settings={settings.accessibility} onUpdate={(n) => setSettings(p => ({ ...p, accessibility: n }))} isInputView={view === 'research' || view === 'site-finder' || view === 'brief'} activeChat={activeChat} />
      <FloatingTTS activeChat={activeChat || null} view={view} />
      <PhoneLayout view={view} onSetView={setView} projects={projects} chats={chats} activeProjectId={activeProjectId} activeChatId={activeChatId} onNewProject={() => setIsProjectModalOpen(true)} onNewChat={handleNewChat} onSelectProject={(id) => { const p = projects.find(x => x.id === id); if (p) window.location.hash = `#/p/${p.customSlug || p.id}`; }} onSelectChat={(id) => window.location.hash = `#/chat/${id}`} onOpenSettings={() => setIsSettingsOpen(true)} onRenameChat={handleRenameChat} onDeleteChat={handleDeleteChat} />
    </div>
  );
};

export default App;
