
/**
 * Ryo AI - Secure Archive & Portable State Engine
 * 
 * This service implements high-density binary compression and 
 * obfuscation to create short, safe "Archive Slugs" that 
 * contain the full research state without external dependencies.
 */

const HEADER = "RYO31_";
const SECRET_KEY = "RYO-SECURE-ARCHIVE-INTEGRITY-KEY";

/**
 * Applies a rolling XOR mask to a Uint8Array to obfuscate data.
 * This makes the Base64 output "safe" from casual snoopers.
 */
function applyMask(data: Uint8Array): Uint8Array {
  const keyBuf = new TextEncoder().encode(SECRET_KEY);
  const result = new Uint8Array(data.length);
  for (let i = 0; i < data.length; i++) {
    result[i] = data[i] ^ keyBuf[i % keyBuf.length];
  }
  return result;
}

/**
 * Converts Uint8Array to URL-safe Base64
 */
function base64UrlEncode(u8: Uint8Array): string {
  let bin = "";
  for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/**
 * Converts URL-safe Base64 to Uint8Array
 */
function base64UrlDecode(str: string): Uint8Array {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) str += '=';
  const bin = atob(str);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

/**
 * Compresses string data using Gzip
 */
async function compress(data: string): Promise<Uint8Array> {
  const stream = new Blob([data]).stream();
  const compressedStream = stream.pipeThrough(new CompressionStream("gzip"));
  const chunks: Uint8Array[] = [];
  const reader = compressedStream.getReader();
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
  }
  const totalLength = chunks.reduce((acc, c) => acc + c.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.length;
  }
  return result;
}

/**
 * Decompresses Gzip Uint8Array to string
 */
async function decompress(u8: Uint8Array): Promise<string> {
  const stream = new Blob([u8]).stream();
  const decompressedStream = stream.pipeThrough(new DecompressionStream("gzip"));
  const chunks: Uint8Array[] = [];
  const reader = decompressedStream.getReader();
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
  }
  const totalLength = chunks.reduce((acc, c) => acc + c.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.length;
  }
  return new TextDecoder().decode(result);
}

/**
 * Simulates a Backend API: Saves project/chat to a secure compressed slug.
 */
export const saveSharedContent = async (type: 'project' | 'chat', data: any): Promise<string> => {
  try {
    // 1. Minify payload
    const payload = JSON.stringify({ t: type, d: data, v: 3 });
    
    // 2. Compress (Gzip)
    const compressed = await compress(payload);
    
    // 3. Obfuscate (XOR)
    const masked = applyMask(compressed);
    
    // 4. Encode (Base64URL)
    return HEADER + base64UrlEncode(masked);
  } catch (e) {
    console.error("Archive packaging failed:", e);
    throw new Error("ARCHIVE_GEN_FAIL");
  }
};

/**
 * Simulates a Backend API: Fetches and decodes the project data from a slug.
 */
export const getSharedContent = async (slug: string): Promise<{ type: string, data: any } | null> => {
  if (!slug.startsWith(HEADER)) return null;
  
  try {
    // 1. Decode
    const masked = base64UrlDecode(slug.substring(HEADER.length));
    
    // 2. Unmask (XOR)
    const compressed = applyMask(masked);
    
    // 3. Decompress (Gzip)
    const payloadStr = await decompress(compressed);
    
    // 4. Parse
    const parsed = JSON.parse(payloadStr);
    return {
      type: parsed.t,
      data: parsed.d
    };
  } catch (e) {
    console.error("Archive retrieval failed:", e);
    return null;
  }
};
