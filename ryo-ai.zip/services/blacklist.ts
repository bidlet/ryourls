
// This file is deprecated. Please use services/aiFilter.ts
export const PROHIBITED_DOMAINS = [];
export const PROHIBITED_KEYWORDS = [];
export const isProhibitedSource = () => false;
export const isTextTainted = () => false;
