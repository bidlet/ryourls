
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { SYSTEM_INSTRUCTION, SITE_FINDER_INSTRUCTION, BRIEF_INSTRUCTION } from "../constants";
import { GroundingSource, FlashcardSet, UserSettings, Flashcard, Chat } from "../types";
import { containsProhibitedContent, isProhibitedUri, containsProhibitedKeywords } from "./aiFilter";

const getAi = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Filter and validate grounding chunks to ensure they are actual pages, not search queries.
 */
const filterGroundingSources = (response: GenerateContentResponse, settings: UserSettings): GroundingSource[] => {
  const candidate = response.candidates?.[0];
  const grounding = candidate?.groundingMetadata;
  
  if (!grounding || !grounding.groundingChunks) return [];
  
  const sources: GroundingSource[] = [];
  grounding.groundingChunks.forEach((chunk: any) => {
    const uri = chunk.web?.uri;
    const title = chunk.web?.title;
    
    if (uri && title) {
      const url = uri.toLowerCase();
      const isSearchEngineResult = 
        (url.includes('google.com') || url.includes('bing.com') || url.includes('yahoo.com')) && 
        (url.includes('/search') || url.includes('q=') || url.includes('query='));
      
      const isBadUri = isProhibitedUri(uri, settings.blacklistedDomains);
      const isBadTitle = containsProhibitedKeywords(title);
      
      if (!isSearchEngineResult && !isBadUri && !isBadTitle) {
        sources.push({ title, uri });
      }
    }
  });
  
  return sources.filter((v, i, a) => a.findIndex(t => t.uri === v.uri) === i);
};

export const generateChatTitle = async (userPrompt: string, modelReply: string): Promise<string> => {
  const ai = getAi();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Based on this first question: "${userPrompt}", generate a short, professional academic title (3-5 words) for this research session. Do not use quotes or markdown. Output only the title.`,
      config: {
        temperature: 0.5,
        thinkingConfig: { thinkingBudget: 0 } // Speed optimization: Disable thinking
      }
    });
    return response.text?.trim() || "Research Session";
  } catch (e) {
    return "Research Session";
  }
};

export const summarizeChat = async (chat: Chat, wordLimit: number = 100): Promise<string> => {
  const ai = getAi();
  const transcript = chat.messages
    .map(m => `${m.role === 'user' ? 'Student' : 'Ryo'}: ${m.text}`)
    .join('\n');

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Summarize the following academic research session into a very concise, bulleted list of takeaways. 
      The summary should be approximately ${wordLimit} words. 
      Use plain text only, no markdown stars or hashes. \n\nTRANSCRIPT:\n${transcript}`,
      config: {
        temperature: 0.3,
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text || "Could not generate summary.";
  } catch (e) {
    return "Summary generation failed due to research complexity.";
  }
};

export const sendMessageToGemini = async (
  prompt: string,
  history: { role: string; parts: { text: string }[] }[] = [],
  settings: UserSettings,
  isSiteFinder = false,
  isBrief = false,
  onStream?: (text: string) => void,
  image?: { data: string; mimeType: string },
  retryCount = 0
): Promise<{ text: string; sources: GroundingSource[] }> => {
  const ai = getAi();
  
  const exclusions = "-site:wikipedia.org -site:reddit.com -site:quora.com -site:fandom.com -site:wikihow.com";
  const trustedSites = "(site:britannica.com OR site:edu OR site:gov OR site:si.edu OR site:loc.gov OR site:archive.org)";
  
  let enforcedPrompt = prompt;
  let dynamicInstruction = SYSTEM_INSTRUCTION;

  if (isSiteFinder) {
    dynamicInstruction = SITE_FINDER_INSTRUCTION;
    enforcedPrompt = `GENERATE A LIST OF 15-20 DIRECT ARTICLE LINKS for the topic: "${prompt}". 
    You MUST use the Google Search tool for EVERY link to provide metadata. 
    Output in plain text. No markdown.
    Search Query: ${prompt} ${trustedSites} ${exclusions}`;
  } else if (isBrief) {
    dynamicInstruction = BRIEF_INSTRUCTION;
    enforcedPrompt = `Fact check and answer in 1-10 words: "${prompt}". 
    Search Query: ${prompt} ${trustedSites} ${exclusions}`;
  } else {
    enforcedPrompt = `Research and answer: "${prompt}". 
    REQUIREMENT: Use the Google Search tool to find scholarly articles.
    TEXT FORMAT: Use plain text ONLY. Do NOT use symbols like #, *, or ---.
    CITATIONS: Do not put citations in the text. Instead, ensure you use the search tool so grounding metadata is generated.
    Search Query: ${prompt} ${trustedSites} ${exclusions}`;
  }

  // Inject custom personality instructions if provided
  if (settings.customPersonality) {
    dynamicInstruction += `\n\nADDITIONAL PERSONALITY INSTRUCTIONS:\n${settings.customPersonality}`;
  }

  try {
    const contents: any[] = [...history];
    const currentPart: any = { text: enforcedPrompt };
    
    const userMessageParts = [currentPart];
    if (image) {
      userMessageParts.push({
        inlineData: {
          data: image.data,
          mimeType: image.mimeType
        }
      });
    }

    contents.push({ role: 'user', parts: userMessageParts });

    const streamResponse = await ai.models.generateContentStream({
      model: "gemini-3-flash-preview",
      contents: contents,
      config: {
        systemInstruction: dynamicInstruction,
        tools: [{ googleSearch: {} }],
        temperature: 0.1,
        thinkingConfig: { thinkingBudget: 0 } // Speed optimization: Disable thinking for instant response
      },
    });

    let fullText = "";
    let finalSources: GroundingSource[] = [];

    for await (const chunk of streamResponse) {
      const textChunk = chunk.text || "";
      fullText += textChunk;
      
      // Update grounding sources as they come in
      const chunkSources = filterGroundingSources(chunk, settings);
      if (chunkSources.length > 0) {
        // Merge and deduplicate sources
        const combined = [...finalSources, ...chunkSources];
        finalSources = combined.filter((v, i, a) => a.findIndex(t => t.uri === v.uri) === i);
      }

      // Stream the text back to UI for perceived zero-latency
      if (onStream) {
        onStream(fullText);
      }
    }

    if (isBrief) {
      return { text: fullText || "Information unavailable.", sources: [] };
    }

    if (isSiteFinder && finalSources.length === 0 && retryCount < 1) {
      return sendMessageToGemini(prompt, history, settings, true, false, onStream, image, retryCount + 1);
    }

    if (isSiteFinder) {
      if (finalSources.length === 0) {
        return {
          text: `NO DIRECT DOCUMENTATION FOUND\n\nI was unable to locate high-integrity article pages for this specific query.`,
          sources: []
        };
      }
      return {
        text: `VERIFIED INSTITUTIONAL ARTICLES AND RESOURCES\n\nI have successfully located the following direct documentation:`,
        sources: finalSources,
      };
    }

    // Only block if the actual text output is tainted. 
    // We trust filterGroundingSources to have already removed the bad sources from the UI list.
    if (settings.strictFilterEnabled && !isBrief && containsProhibitedContent(fullText, [], settings)) {
       return {
        text: "[INTEGRITY ALERT]\n\nThe academic engine detected unreliable user-edited content in the generated response. Access was blocked to maintain scholarly standards.",
        sources: [],
      };
    }

    return { text: fullText || "Research concluded.", sources: finalSources };
  } catch (error: any) {
    if (error.status === 429) throw new Error("QUOTA_EXHAUSTED");
    console.error("Gemini API Error:", error);
    throw error;
  }
};

export const generateFlashcards = async (topic: string, wordLimit: number, settings: UserSettings): Promise<FlashcardSet> => {
  const ai = getAi();
  try {
    const prompt = `Generate 5-8 academic flashcards for: ${topic}. 
    Each "back" must be approximately ${wordLimit} words. 
    Output ONLY plain text within the JSON values.
    Return ONLY JSON: { "topic": "${topic}", "cards": [{ "front": "Term", "back": "Explanation" }] }`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION + `\nRespond ONLY in JSON. NO MARKDOWN CHARACTERS. CITATIONS VIA GOOGLE SEARCH TOOL REQUIRED.`,
        tools: [{ googleSearch: {} }],
        temperature: 0.1,
        thinkingConfig: { thinkingBudget: 0 } // Speed optimization
      }
    });

    const text = response.text || "";
    const rawSources = filterGroundingSources(response, settings);

    let jsonStr = text.trim();
    if (jsonStr.includes('```json')) jsonStr = jsonStr.split('```json')[1].split('```')[0].trim();
    else if (jsonStr.includes('```')) jsonStr = jsonStr.split('```')[1].split('```')[0].trim();

    const rawData = JSON.parse(jsonStr || "{}");
    
    return {
      id: Date.now().toString(),
      topic: rawData.topic || topic,
      cards: rawData.cards || [],
      sources: rawSources,
      createdAt: Date.now()
    };
  } catch (error: any) {
    if (error.status === 429) throw new Error("QUOTA_EXHAUSTED");
    throw new Error("Validation failed.");
  }
};
