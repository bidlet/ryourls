
import { Project } from "../types";

/**
 * Ryo AI Ultra-Advanced Voice Intent Engine
 * Handles fuzzy matching, sensitive filtering, dynamic parameter extraction, and system-level toggles.
 */

type CommandCallback = (action: { type: string, target: string, data?: string }) => void;

interface IntentMapping {
  keywords: string[];
  target: string;
  type: 'NAVIGATE' | 'ACTION';
}

const INTENTS: IntentMapping[] = [
  { 
    keywords: ['voice', 'vog', 'vois', 'voyce', 'rasich', 'research', 're-search', 'talk', 'speak'], 
    target: '#/voice', 
    type: 'NAVIGATE' 
  },
  { 
    keywords: ['brief', 'bref', 'fast', 'quick', 'answer', 'ansur', 'short'], 
    target: '#/brief', 
    type: 'NAVIGATE' 
  },
  { 
    keywords: ['research', 'rasich', 'search', 'lab', 'main', 'home'], 
    target: '#/research', 
    type: 'NAVIGATE' 
  },
  { 
    keywords: ['site', 'finder', 'find', 'sit', 'funder', 'links'], 
    target: '#/site-finder', 
    type: 'NAVIGATE' 
  },
  { 
    keywords: ['study', 'cards', 'flash', 'flashcards', 'studi', 'card'], 
    target: '#/flashcards', 
    type: 'NAVIGATE' 
  },
  { 
    keywords: ['vault', 'settings', 'setins', 'valt', 'archive', 'security', 'recovery'], 
    target: 'OPEN_SETTINGS', 
    type: 'ACTION' 
  },
  { 
    keywords: ['new', 'project', 'proj', 'create', 'start'], 
    target: 'NEW_PROJECT', 
    type: 'ACTION' 
  },
  {
    keywords: ['search bar', 'open search', 'find chat', 'look up chat', 'search everything'],
    target: 'OPEN_SEARCH',
    type: 'ACTION'
  },
  {
    keywords: ['delete this chat', 'delete chat', 'remove chat', 'trash this chat'],
    target: 'DELETE_CURRENT_CHAT',
    type: 'ACTION'
  },
  {
    keywords: ['dark mode', 'dark theme', 'night mode', 'black mode'],
    target: 'THEME_DARK',
    type: 'ACTION'
  },
  {
    keywords: ['light mode', 'light theme', 'day mode', 'white mode'],
    target: 'THEME_LIGHT',
    type: 'ACTION'
  },
  {
    keywords: ['yes', 'confirm', 'do it', 'correct', 'yep', 'yeah', 'sure'],
    target: 'VOICE_CONFIRM_YES',
    type: 'ACTION'
  },
  {
    keywords: ['no', 'cancel', 'abort', 'don\'t', 'nope', 'stop'],
    target: 'VOICE_CONFIRM_NO',
    type: 'ACTION'
  }
];

let recognition: any = null;
let isExpectedStopping = false;

export const initVoiceControl = (projects: Project[], onCommand: CommandCallback) => {
  const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  if (!SpeechRecognition) return null;

  if (recognition) {
    isExpectedStopping = true;
    recognition.stop();
  }

  recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = false;
  recognition.lang = 'en-US';
  isExpectedStopping = false;

  recognition.onresult = (event: any) => {
    const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
    console.log("Voice Command Detected:", transcript);

    // 1. DYNAMIC COMMAND EXTRACTION
    
    // Create Project with Proper Capitalization
    const createProjectPatterns = [
      /make a (?:new )?project called (.+)/,
      /create a (?:new )?project called (.+)/,
      /create (?:a )?project named (.+)/,
      /new project called (.+)/
    ];

    for (const pattern of createProjectPatterns) {
      const match = transcript.match(pattern);
      if (match && match[1]) {
        // Capitalize the first letter of each word for the project name
        const rawName = match[1].trim();
        const formattedName = rawName.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
        onCommand({ type: 'ACTION', target: 'CREATE_PROJECT_WITH_NAME', data: formattedName });
        return;
      }
    }

    // Change Personality
    const personalityPatterns = [
      /change mode to (.+)/,
      /switch mode to (.+)/,
      /change personality to (.+)/,
      /switch personality to (.+)/,
      /set personality to (.+)/,
      /go to (academic|encouraging|concise|socratic) mode/
    ];

    for (const pattern of personalityPatterns) {
      const match = transcript.match(pattern);
      if (match) {
        const p = match[1].trim().charAt(0).toUpperCase() + match[1].trim().slice(1).toLowerCase();
        onCommand({ type: 'ACTION', target: 'CHANGE_PERSONALITY', data: p });
        return;
      }
    }

    // 2. INTENT MATCHING
    const words = transcript.split(/\s+/);
    const triggers = ['open', 'go', 'to', 'show', 'navigate', 'delete', 'turn', 'switch', 'enable', 'activate'];
    const hasTrigger = words.some(w => triggers.includes(w));

    let bestIntent: IntentMapping | null = null;
    let highestScore = 0;

    for (const intent of INTENTS) {
      let score = 0;
      for (const keyword of intent.keywords) {
        if (transcript.includes(keyword)) score += 3;
      }

      // Voice confirmation and theme toggles are high sensitivity
      const isSensitive = intent.target.startsWith('VOICE_CONFIRM') || intent.target.startsWith('THEME');
      
      if (score >= 6 || (hasTrigger && score >= 3) || (isSensitive && score >= 3)) {
        if (score > highestScore) {
          highestScore = score;
          bestIntent = intent;
        }
      }
    }

    if (bestIntent) {
      onCommand({ type: bestIntent.type, target: bestIntent.target });
    }
  };

  recognition.onend = () => {
    // If it stops unexpectedly (silent pause, network blip), restart it immediately
    if (!isExpectedStopping) {
      try { recognition.start(); } catch (e) {}
    }
  };

  recognition.onerror = (e: any) => {
    console.warn("Voice Engine Warning:", e.error);
    if (e.error === 'not-allowed') {
      isExpectedStopping = true;
    }
  };

  return {
    start: () => {
      isExpectedStopping = false;
      try { recognition.start(); } catch (e) {}
    },
    stop: () => {
      isExpectedStopping = true;
      try { recognition.stop(); } catch (e) {}
    },
  };
};
