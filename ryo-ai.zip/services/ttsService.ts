
import { GoogleGenAI, Modality } from "@google/genai";

let sharedAi: GoogleGenAI | null = null;
let sharedAudioCtx: AudioContext | null = null;

const getAi = () => {
  if (!sharedAi) {
    sharedAi = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
  return sharedAi;
};

const getAudioContext = () => {
  if (!sharedAudioCtx) {
    sharedAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  }
  return sharedAudioCtx;
};

/**
 * Splits text into small, synthesizable chunks (sentences/phrases).
 * This is the secret to "instant" audio - synthesizing 10 words is 10x faster than 100 words.
 */
export const splitIntoChunks = (text: string): string[] => {
  // Split by common sentence terminators but keep the punctuation
  return text
    .split(/([.!?]+\s+)/g)
    .reduce((acc: string[], curr, i) => {
      if (i % 2 === 0) {
        acc.push(curr);
      } else {
        acc[acc.length - 1] += curr;
      }
      return acc;
    }, [])
    .filter(chunk => chunk.trim().length > 0);
};

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const synthesizeText = async (text: string, voiceName: string): Promise<AudioBuffer | null> => {
  if (!text.trim()) return null;
  const ai = getAi();
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      const ctx = getAudioContext();
      return await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
    }
  } catch (error) {
    console.error("Synthesis failed:", error);
  }
  return null;
};

export const playBuffer = (buffer: AudioBuffer, speed: number = 1.0): AudioBufferSourceNode => {
  const ctx = getAudioContext();
  const source = ctx.createBufferSource();
  source.buffer = buffer;
  source.playbackRate.value = speed;
  source.connect(ctx.destination);
  source.start();
  return source;
};

export const speakText = async (text: string, voiceName: string, speed: number = 1.0) => {
  const chunks = splitIntoChunks(text);
  // For one-off speech, we still chunk but play sequentially for faster "First Byte"
  for (const chunk of chunks) {
    const buffer = await synthesizeText(chunk, voiceName);
    if (buffer) {
      const source = playBuffer(buffer, speed);
      await new Promise(r => source.onended = r);
    }
  }
};
