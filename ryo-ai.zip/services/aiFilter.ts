
import { UserSettings } from "../types";

export const PROHIBITED_DOMAINS = [
  'wikipedia.org',
  'wikihow.com',
  'wiktionary.org',
  'wikimedia.org',
  'fandom.com',
  'wikia.org',
  'wikia.com',
  'rationalwiki.org',
  'citizendium.org',
  'conservapedia.com',
  'wikibooks.org',
  'wikidata.org',
  'wikinews.org',
  'wikiquote.org',
  'wikisource.org',
  'wikiversity.org',
  'wikivoyage.org',
  'answers.com',
  'quora.com',
  'brainly.com',
  'reddit.com',
  'wiki.com',
  'urbanlexicon.com',
  'knowyourmeme.com',
  'aljazeera.com',
  'aljazeera.net',
  'wiktionary.org'
];

export const PROHIBITED_KEYWORDS = [
  'wikipedia',
  'wikihow',
  'fandom',
  'reddit',
  'quora',
  'brainly',
  'al jazeera',
  'aljazeera',
  'sourced from wiki',
  'wikipedia article',
  'according to reddit',
  'quora user'
];

export const containsProhibitedKeywords = (text: string): boolean => {
  const textLower = text.toLowerCase();
  // We check for full keywords to avoid false positives on parts of medical/scientific words
  return PROHIBITED_KEYWORDS.some(kw => textLower.includes(kw.toLowerCase()));
};

export const containsProhibitedContent = (text: string, sources: any[], settings: UserSettings): boolean => {
  if (!settings.strictFilterEnabled) return false;
  
  // If the text explicitly mentions a prohibited source in a way that suggests reliance
  if (containsProhibitedKeywords(text)) return true;

  // We don't check sources here anymore because geminiService.filterGroundingSources 
  // already removes them from the visible list. If the model output text is clean,
  // we shouldn't block the response just because a prohibited site appeared in 
  // the raw background search results.
  
  return false;
};

export const isProhibitedUri = (uri: string, customBlacklist: string[] = []): boolean => {
  const url = uri.toLowerCase();
  
  // Hard blocks for specific academic integrity hazards
  const prohibitedFragments = [
    'wikipedia.org', 
    'wikihow.com', 
    'reddit.com', 
    'fandom.com', 
    'quora.com', 
    'brainly.com', 
    'wikia.com',
    'wikimedia.org',
    'aljazeera.com',
    'wiktionary.org'
  ];

  if (prohibitedFragments.some(fragment => url.includes(fragment))) {
    return true;
  }

  const allProhibited = [...PROHIBITED_DOMAINS, ...customBlacklist];
  return allProhibited.some(domain => {
    const cleanDomain = domain.toLowerCase().trim();
    return cleanDomain && url.includes(cleanDomain);
  });
};
