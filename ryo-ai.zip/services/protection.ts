
/**
 * Ryo AI "Hardened" Security Engine v2.5 - Instant Enforcement
 * 
 * UPDATES:
 * - Removed all opacity transitions and timeouts for visual effects.
 * - Shield now triggers with zero latency (no fade-in).
 * - Focus Monitoring and Split-Screen detection remain at high-priority intervals.
 * - RELEASE DELAY: Added 1 second buffer to the shield removal for extra persistence.
 */

export const initSecurityProtection = () => {
  const noScreenshot = (window as any).noScreenshot;
  const noCopy = (window as any).noCopy;

  if (!noScreenshot) return;

  // 1. Create the Blur Shield
  const createShield = () => {
    let s = document.getElementById('ryo-security-shield');
    if (!s) {
      s = document.createElement('div');
      s.id = 'ryo-security-shield';
      Object.assign(s.style, {
        position: 'fixed',
        top: '0',
        left: '0',
        width: '100vw',
        height: '100vh',
        zIndex: '2147483647',
        backdropFilter: 'blur(15px)',
        WebkitBackdropFilter: 'blur(15px)',
        backgroundColor: 'rgba(255, 255, 255, 0.4)',
        display: 'none',
        pointerEvents: 'none',
        transform: 'translateZ(0)',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        color: '#4f46e5',
        textAlign: 'center',
        padding: '20px'
      });
      
      const msg = document.createElement('div');
      msg.innerHTML = `
        <div style="background: white; padding: 2.5rem; border-radius: 2rem;">
          <h2 style="font-weight: 800; font-size: 1.75rem; margin-bottom: 0.75rem; color: #1e293b;">Security Enforcement</h2>
          <p style="font-size: 1rem; color: #64748b; line-height: 1.5;">Ryo AI requires full screen focus to maintain academic integrity.<br/>Please maximize this window and close overlaying apps.</p>
        </div>
      `;
      s.appendChild(msg);
      
      document.documentElement.appendChild(s);
    }
    return s;
  };

  const shield = createShield();
  let removalTimer: number | null = null;

  const triggerShield = () => {
    if (removalTimer) {
      clearTimeout(removalTimer);
      removalTimer = null;
    }
    shield.style.display = 'flex';
  };

  const releaseShield = (delay = 1300) => {
    if (removalTimer) clearTimeout(removalTimer);
    removalTimer = window.setTimeout(() => {
      shield.style.display = 'none';
      removalTimer = null;
    }, delay);
  };

  // 2. Multi-Context Detection Logic
  const checkEnvironmentIntegrity = () => {
    // A. Detect Focus Loss
    const hasFocus = document.hasFocus();
    
    // B. Detect Split Screen / Resized Window
    const isSplitScreen = window.outerWidth < (window.screen.availWidth * 0.94);
    
    // C. Detect Visibility
    const isVisible = document.visibilityState === 'visible';

    if (!hasFocus || isSplitScreen || !isVisible) {
      triggerShield();
      return true;
    }
    
    return false;
  };

  // 3. Heartbeat Monitor (250ms)
  const monitorInterval = setInterval(() => {
    const isViolated = checkEnvironmentIntegrity();
    if (!isViolated) {
      if (shield.style.display !== 'none' && !removalTimer) {
        // Delay increased by 1 second (from 100ms to 1100ms)
        releaseShield(1100);
      }
    }
  }, 250);

  // 4. Keyboard Interception
  const interceptKeys = (e: KeyboardEvent) => {
    const key = e.key || '';
    const code = e.code || '';
    const isPrtSc = key === 'PrintScreen' || code === 'PrintScreen' || e.keyCode === 44;
    const isWindowsKey = (key === 'Meta' || key === 'OS' || code === 'MetaLeft' || code === 'MetaRight');
    const isMacScreenshot = e.metaKey && e.shiftKey && ['3', '4', '5'].includes(key);
    const isDevTools = (e.ctrlKey && e.shiftKey && (key === 'I' || key === 'J' || key === 'C')) || (key === 'F12');

    if (isPrtSc || (isWindowsKey && e.type === 'keydown') || isMacScreenshot || isDevTools) {
      triggerShield();
      if (isPrtSc || isDevTools || isMacScreenshot) {
        if (!isWindowsKey) {
            e.preventDefault();
            e.stopPropagation();
        }
      }
      // Increased delays by 1 second for persistence
      releaseShield(isPrtSc ? 3000 : 1500);
    }
  };

  window.addEventListener('keydown', interceptKeys, true);
  window.addEventListener('keyup', interceptKeys, true);
  window.addEventListener('resize', checkEnvironmentIntegrity, true);

  // 5. Anti-Tamper
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.removedNodes) {
        mutation.removedNodes.forEach((node: any) => {
          if (node.id === 'ryo-security-shield') createShield();
        });
      }
    }
  });
  observer.observe(document.documentElement, { childList: true });

  // 6. Interaction Restrictions
  if (noCopy) {
    document.addEventListener('contextmenu', e => {
        if (!e.shiftKey) e.preventDefault();
    }, true);
    document.addEventListener('copy', e => e.preventDefault(), true);
    document.addEventListener('cut', e => e.preventDefault(), true);
  }

  // Print Protection
  window.addEventListener('beforeprint', triggerShield);
  window.addEventListener('afterprint', () => releaseShield(1500));

  // 7. Touch & Select Protection
  const style = document.createElement('style');
  style.innerHTML = `
    * {
      -webkit-touch-callout: none !important;
      -webkit-user-select: none !important;
      user-select: none !important;
    }
    input, textarea, [contenteditable="true"] {
      -webkit-user-select: text !important;
      user-select: text !important;
    }
    @media print {
      body { display: none !important; }
    }
  `;
  document.head.appendChild(style);

  return () => clearInterval(monitorInterval);
};
