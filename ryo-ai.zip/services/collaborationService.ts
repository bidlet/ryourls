
import { UserSettings } from "../types";

const COLLAB_COLORS = [
  { name: 'Indigo', class: 'bg-indigo-600', text: 'text-indigo-600', border: 'border-indigo-600' },
  { name: 'Rose', class: 'bg-rose-600', text: 'text-rose-600', border: 'border-rose-600' },
  { name: 'Emerald', class: 'bg-emerald-600', text: 'text-emerald-600', border: 'border-emerald-600' },
  { name: 'Amber', class: 'bg-amber-600', text: 'text-amber-600', border: 'border-amber-600' },
  { name: 'Violet', class: 'bg-violet-600', text: 'text-violet-600', border: 'border-violet-600' },
  { name: 'Cyan', class: 'bg-cyan-600', text: 'text-cyan-600', border: 'border-cyan-600' },
  { name: 'Orange', class: 'bg-orange-600', text: 'text-orange-600', border: 'border-orange-600' },
];

export const getOrInitUser = (settings: UserSettings): UserSettings => {
  if (settings.userId && settings.userColor) return settings;

  const userId = Math.random().toString(36).substring(2, 10);
  const colorObj = COLLAB_COLORS[Math.floor(Math.random() * COLLAB_COLORS.length)];
  
  return {
    ...settings,
    userId,
    userColor: colorObj.name,
    userName: `Researcher ${userId.toUpperCase()}`
  };
};

export const getColorStyles = (colorName?: string) => {
  const color = COLLAB_COLORS.find(c => c.name === colorName) || COLLAB_COLORS[0];
  return color;
};
