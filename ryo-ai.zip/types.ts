
export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  imageUrl?: string;
  sources?: GroundingSource[];
  timestamp: number;
  senderId?: string;
  senderColor?: string;
  senderName?: string;
  versions?: { 
    text: string; 
    sources?: GroundingSource[]; 
    timestamp: number 
  }[];
  activeVersionIndex?: number;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface Chat {
  id: string;
  projectId: string;
  name: string;
  messages: Message[];
  updatedAt: number;
  deletedAt?: number;
  isTemporary?: boolean;
  expiresAt?: number;
  isSharedProject?: boolean;
}

export interface Project {
  id: string;
  name: string;
  customSlug?: string;
  chatIds: string[];
  createdAt: number;
  personality: AIPersonality;
  ownerId?: string;
  defaultVoiceId?: string;
  isPublished?: boolean;
}

export interface Flashcard {
  front: string;
  back: string;
}

export interface FlashcardSet {
  id: string;
  topic: string;
  cards: Flashcard[];
  sources: GroundingSource[];
  createdAt: number;
}

export type AIPersonality = 'Academic' | 'Encouraging' | 'Concise' | 'Socratic';

export type ScreenOverlayType = 'none' | 'sepia' | 'calm-blue' | 'soft-rose' | 'low-light';

export interface AccessibilitySettings {
  dyslexiaFont: boolean;
  dyslexiaFontType: 'open' | 'lexend';
  textScale: number; // e.g., 0.8, 1.0, 1.2, 1.5
  subtleColors: boolean;
  lineHeight: number;
  letterSpacing: number;
  highlightLinks: boolean;
  largeCursor: boolean;
  voiceControlEnabled: boolean;
  // ADHD Focus Toolkit
  readingMask: boolean;
  paragraphFocus: boolean;
  zenMode: boolean;
  screenOverlay: ScreenOverlayType;
  pomodoroEnabled: boolean;
}

export interface UserSettings {
  personality: AIPersonality;
  customPersonality?: string;
  blacklistedDomains: string[];
  strictFilterEnabled: boolean;
  theme: 'light' | 'dark';
  accessibility: AccessibilitySettings;
  userId?: string;
  userColor?: string;
  userName?: string;
}

export type ViewType = 'research' | 'flashcards' | 'site-finder' | 'brief' | 'project-home' | 'voice';
